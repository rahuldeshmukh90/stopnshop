<?php

/**
* 
*/
class Customer_model extends CI_Model
{
	
	function __construct()
	{
		# code...
	}

	function get_all_customers(){

            $query = $this->db-> get('customers');
            return $query;

           // print_r($query); die();
 

        }

     function add_customer(){

                

     $data = array(  
                            'name'      => $this->input->post('name'),
                            'lastName'      => $this->input->post('lastName'),  
                            'contact'     => $this->input->post('contact'),
                            'email'      => $this->input->post('email'),
                            'password'      => md5($this->input->post('password')),
                            'dob'      => $this->input->post('dob'),
                            'addedDate'      => date("Y-m-d h:i:s"),
                            'updatedDate'      => date("Y-m-d h:i:s"),  
                            'randomString'     => rand(1000, 9999)  
                            //date_default_timezone_set("Asia/Kolkata"),


                             
                   );

                          return   $this->db->insert('customers',$data);    

        }

    function get_customer($id)  
        {  
            
        	  $query = $this->db->get_where('customers', array('id'=>$id));
            return $query->row();
            
        }

    function update_customer()  
        {  

           $data = array( 
                            //'id'        => $this->input->post('id'),  
                            'name'      => $this->input->post('name'),
                            'lastName'      => $this->input->post('lastName'),  
                            'contact'     => $this->input->post('contact'),
                            'email'      => $this->input->post('email'),
                            'password'      => md5($this->input->post('password')),
                            'dob'      => $this->input->post('dob'),
                            'addedDate'      => date("Y-m-d h:i:s"),
                            'updatedDate'      => date("Y-m-d h:i:s"),  
                            'randomString'     => rand(1000, 9999)    
                   ); 
         
                //print_r($data); die();
                     
                      $this->db->where('id',$this->input->post('id')); 
                      $this->db->update('customers',$data);

                    
                      
       } 

      function delete_customer($id)  {  
                        
                        
                          $data = array(  
                                          'id' => $id,
                                       );
                      
                          $query = $this->db->delete("customers", $data);  

                          return $query;
                    
       } 

    function get_store(){

            $query = $this->db-> get('sa_store');
            return $query;

}


    function get_store_by_id($id){

           $query = $this->db->get_where('sa_store', array('id'=>$id));
            return $query->row();

}

    function update_store(){

 $errors= array();

  foreach($_FILES['file']['tmp_name'] as $key => $tmp_name ){
    
    $file_name = $key.$_FILES['file']['name'][$key];
 //print_r($file_name);
    $file_size =$_FILES['file']['size'][$key];
    
    $file_tmp =$_FILES['file']['tmp_name'][$key];

    $file_type=$_FILES['file']['type'][$key]; 

        if($file_size > 2097152){
      $errors[]='File size must be less than 2 MB';
        }   
       
        $desired_dir="upload";
        if(empty($errors)==true){
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 0700);    // Create directory if it does not exist
            }
            if(is_dir("$desired_dir/".$file_name)==false){
                move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
            }else{                  // rename the file if another one exist
                $new_dir="$desired_dir/".$file_name.time();
                 rename($file_tmp,$new_dir) ;       
            }
       
        }else{
                print_r($errors);
        }
    }
  if(empty($error)){
    echo "Success";
  }

   $str = serialize($_FILES['file']['name']); 

  //print_r($str) ; die();

//                 $f_name = $_FILES['images']['name'];
//                 $f_tmp = $_FILES['images']['tmp_name'];
//                 $f_extension = explode('.',$f_name); //To breaks the string into array
//                 $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
//                 $f_newfile="";
//                 if($f_name){
//                 $f_newfile = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
//                 $store = "upload/" . $f_newfile;
//                 $file1 =  move_uploaded_file($f_tmp,$store);
//                 }
// echo $f_newfile ; die();
            $data = array( 
                            'id'        => $this->input->post('id'),  
                            'name'      => $this->input->post('name'),  
                            'latitude'     => $this->input->post('latitude'),  
                            'longitude'  => $this->input->post('longitude'),  
                            'address'   => $this->input->post('address'),  
                            'email'   => $this->input->post('email'),  
                            //'contact'   => $this->input->post('contact'),
                            'contact2'   => $this->input->post('contact2'),  
                            'images'   => $str   
                                
                   ); 
         
             //   print_r($data); die();
                     
                      $this->db->where('id',$this->input->post('id')); 
                      $this->db->update('sa_store',$data);

} 
}