<?php

/**
* 
*/
class Customer_model extends CI_Model
{
	
	function __construct()
	{
		# code...
	}

  function getlatestcustomer(){

          $this->db->select('*');
          $this->db->order_by('id', 'DESC');  
          $this->db->from('customers');
          $this->db->limit('10');
          // $this->db->where(array('checklist_item_id' => $id, 'status' => 1));
          $query = $this->db->get();
          //print_r($query); die();
          return $query->result_array();  

  }

	function get_all_customers($limit, $offset){

            $this->db->select('*');
            $this->db->from('customers');
            $this->db->limit($limit, $offset);
            return $query=$this->db->get();

            //$query = $this->db-> get('customers');
            //return $query;

           // print_r($query); die();
 

        }

     function add_customer(){

                

     $data = array(  
                            'name'      => $this->input->post('name'),
                            'lastName'      => $this->input->post('lastName'),  
                            'contact'     => $this->input->post('contact'),
                            'email'      => $this->input->post('email'),
                            'password'      => md5($this->input->post('password')),
                            'dob'      => $this->input->post('dob'),
                            'addedDate'      => date("Y-m-d h:i:s"),
                            'updatedDate'      => date("Y-m-d h:i:s"),  
                            'randomString'     => rand(1000, 9999)  
                            //date_default_timezone_set("Asia/Kolkata"),


                             
                   );

                          return   $this->db->insert('customers',$data);    

        }

    function get_customer($id)  
        {  
            
        	  $query = $this->db->get_where('customers', array('id'=>$id));
            return $query->row();
            
        }

    function update_customer()  
        {  


// if(empty($this->input->post('password')))
// {
//   $pass = '';

// }else{
   
//       $pass = $this->input->post('password');             
// }

           $data = array( 
                            //'id'        => $this->input->post('id'),  
                            'name'      => $this->input->post('name'),
                            'lastName'      => $this->input->post('lastName'),  
                            'contact'     => $this->input->post('contact'),
                            'email'      => $this->input->post('email'),
                            //'password'      => md5($pass),
                            'dob'      => $this->input->post('dob'),
                            'addedDate'      => date("Y-m-d h:i:s"),
                            'updatedDate'      => date("Y-m-d h:i:s"),  
                            'randomString'     => rand(1000, 9999)    
                   ); 
         
                        if ($this->input->post('password')!='') {
                            $data['password'] = md5($this->input->post('password')); 
                }
                     
                      $this->db->where('id',$this->input->post('id')); 
                      $query = $this->db->update('customers',$data);

                      if ($query) {
                         return true;

                       } else{

                         return false;
                       }

                    
                      
       } 

      function delete_customer($id)  {  
                        
                        
                          $data = array(  
                                          'id' => $id,
                                       );
                      
                          $query = $this->db->delete("customers", $data);  

                          return $query;
                    
       } 

    function get_store(){

            
			
			$this->db->select("*");
        $this->db->from('sa_store');  
        $query = $this->db->get();
        return $result=$query->row();

        }
   function get_image(){

            $this->db->select('images');
					$this->db->from('sa_store');
					
					//$this->db->limit($limit,$offset);
			$reault_array = $this->db->get()->result_array();
            return $reault_array[0]['images'];
			//print_r($r); die();
            //return $query;

}


    function get_store_by_id($id){

           $query = $this->db->get_where('sa_store', array('id'=>$id));
            return $query->row();

}

    function update_store(){
// echo "string"; die();
 
if(empty($_FILES['new_images']['name']))
{
  $f_newfile = $this->input->post('old_images');
}else{
   // echo"up"; die();
                $f_name = $_FILES['new_images']['name'];
                $f_tmp = $_FILES['new_images']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile="";
                if($f_name){
                $f_newfile = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
}

if(empty($_FILES['new_images2']['name']))
{
  $f_newfile2 = $this->input->post('old_images2');
}else{
   // echo"up"; die();
                $f_name = $_FILES['new_images2']['name'];
                $f_tmp = $_FILES['new_images2']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile2="";
                if($f_name){
                $f_newfile2 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile2;
                $file2 =  move_uploaded_file($f_tmp,$store);
                }
}


if(empty($_FILES['new_images3']['name']))
{
  $f_newfile3 = $this->input->post('old_images3');
}else{
   // echo"up"; die();
                $f_name = $_FILES['new_images3']['name'];
                $f_tmp = $_FILES['new_images3']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile3="";
                if($f_name){
                $f_newfile3 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile3;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
}


if(empty($_FILES['new_images4']['name']))
{
  $f_newfile4 = $this->input->post('old_images4');
}else{
   // echo"up"; die();
                $f_name = $_FILES['new_images4']['name'];
                $f_tmp = $_FILES['new_images4']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile4="";
                if($f_name){
                $f_newfile4 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile4;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
}

if(empty($_FILES['new_images5']['name']))
{
  $f_newfile5 = $this->input->post('old_images5');
}else{
   // echo"up"; die();
                $f_name = $_FILES['new_images5']['name'];
                $f_tmp = $_FILES['new_images5']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile5="";
                if($f_name){
                $f_newfile5 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile5;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
}

if(empty($_FILES['new_images6']['name']))
{
  $f_newfile6 = $this->input->post('old_images6');
}else{
   // echo"up"; die();
                $f_name = $_FILES['new_images6']['name'];
                $f_tmp = $_FILES['new_images6']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile6="";
                if($f_name){
                $f_newfile6 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile6;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
}



            $data = array( 
                            // 'id'        => $this->input->post('id'),  
                            'name'      => $this->input->post('name'),  
                            'latitude'     => $this->input->post('latitude'),  
                            'longitude'  => $this->input->post('longitude'),  
                            'address'   => $this->input->post('address'),  
                            'email'   => $this->input->post('email'),  
                            'contact'   => $this->input->post('contact'),
                            'contact2'   => $this->input->post('contact2'),  
                            'images'   => $f_newfile,
                            'images2'   => $f_newfile2,
                            'images3'   => $f_newfile3,
                            'images4'   => $f_newfile4,
                            'images5'   => $f_newfile5,
                            'images6'   => $f_newfile6
                                
                   ); 
         
             //   print_r($data); die();
                     
                            $this->db->where('id',$this->input->post('id')); 
                    return  $this->db->update('sa_store',$data);

} 

    function total_customers()  
        {  

            $this->db->select('count(*)');
            $query = $this->db->get('customers');
            $cnt = $query->row_array();
            return $cnt['count(*)']; 

             //print_r($r); die(); 
     }                 

}
