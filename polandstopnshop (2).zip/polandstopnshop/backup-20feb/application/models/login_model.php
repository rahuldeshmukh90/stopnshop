<?php

class Login_model extends CI_Model
{
	

	function admin_logedin(){


		         $data = array( 
		                             'admin_email' =>  $this->input->post('admin_email'),    
		                             'password'    =>  md5($this->input->post('password'))    
		                       ); 


		                      $condition = "admin_email =" . "'" . $data['admin_email'] . "' AND " . "password =" . "'" . $data['password'] . "'";

		                      $this->db->select('*');
		                      $this->db->from('admin_login');
		                      $this->db->where($condition);
		                      
		                      $query = $this->db->get();

                    //print_r($query) ; die();

		                      if ($query->num_rows() == 1) {


		                      $row = $query->row();

                               //print_r($row); die();

		                      //echo $row->id ; die();

			                   $this->session->set_userdata('id',$row->id);
			                   // echo $this->session->userdata('id'); die();
			                    // print_r($r); die();
		                      return true;

		                      } else {

		                      return false;
		                      }

	}

	function admin_info($email){
         
                $query = $this->db->get_where('admin_login', array('id'=>$email));
                return $query->row();


	}

	function get_admin_info($id){
         
                $query = $this->db->get_where('admin_login', array('id'=>$id));
                return $query->row();


	}

	function update_admin_info(){
         
                // $f_name1 = $_FILES['image']['name'];
                // $f_tmp1 = $_FILES['image']['tmp_name'];
                // $f_extension1 = explode('.',$f_name1); //To breaks the string into array
                // $f_extension1 = strtolower(end($f_extension1)); //end() is used to retrun a last element to the array
                // $f_newfile1="";
                // if($f_name1){
                // $f_newfile1 = uniqid().'.'.$f_extension1; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                // $store1 = "upload/" . $f_newfile1;
                // $file2 =  move_uploaded_file($f_tmp1,$store1);
                // }

		   // if(empty($this->input->post('password'))){ $pass = '';  } else
		   //  { $pass = $this->input->post('password'); }        
        	
           

           $data = array( 
                            //'id' => $this->input->post('id'),  
                            'admin_name' => $this->input->post('admin_name'),
                            //'password'   => md5($pass),  
                            //'image' => $f_newfile1, 
                            'admin_email'=> $this->input->post('admin_email'),  
                            'contact_no' => $this->input->post('contact_no')
                            //'address' => $this->input->post('address'),
                   ); 
         
		                if ($this->input->post('password')!='') {
		                    $data['password'] = md5($this->input->post('password'));
                }
                     
                      $this->db->where('id',$this->input->post('id')); 
                      $this->db->update('admin_login',$data);



	}

	function is_logged_in()
	{
		return $this->session->userdata('id')!=false;
	}
	

    function get_logged_in_user_info()
	{
		if ($this->is_logged_in()) {
			return $this->admin_info($this->session->userdata('id'));
		}
		return true;
	}
}