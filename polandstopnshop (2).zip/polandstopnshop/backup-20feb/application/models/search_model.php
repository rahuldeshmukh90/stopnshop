<?php

/**
* 
*/
class Search_model extends CI_Model
{
	
	function __construct()
	{
		# code...
	}

	public function get_results($search_term, $limit ,$offset)
    {
        // Use the Active Record class for safer queries.
        $this->db->select('*');
        $this->db->from('sa_products');
        $this->db->like('name',$search_term);
        $this->db->limit($limit, $offset);
        // Execute the query.
        $this->db->where('product_type' ,'simple');
        $query = $this->db->get();

        // Return the results.
        return $query->result_array();
    }

    public function get_comboresults($search_term1, $limit ,$offset)
    {
        // Use the Active Record class for safer queries.
        $this->db->select('*');
        $this->db->from('sa_products');
        $this->db->like('name',$search_term1);
        $this->db->limit($limit, $offset);
        $this->db->where('product_type' ,'combo');
        // Execute the query.
        $query = $this->db->get();

        // Return the results.
        return $query->result_array();
    }
	
	public function count_search_results($search_term)
    {
        // Use the Active Record class for safer queries.
        $this->db->select('*');
        $this->db->from('sa_products');
        $this->db->like('name',$search_term);
        $this->db->where('product_type' ,'simple');
        // Execute the query.
        $query = $this->db->get();

        // Return the results.
        return $query->num_rows();
    }

    public function count_searchcombo_results($search_term)
    {
        // Use the Active Record class for safer queries.
        $this->db->select('*');
        $this->db->from('sa_products');
        $this->db->like('name',$search_term);
        $this->db->where('product_type' ,'combo');
        // Execute the query.
        $query = $this->db->get();

        // Return the results.
        return $query->num_rows();
    }

    public function count_searchcustomer_results($search_term2)
    {
        
        $this->db->select('*');
        $this->db->from('customers');
        $this->db->like('name',$search_term2);
        // Execute the query.
        $query = $this->db->get();

        // Return the results.
        return $query->num_rows();
    }

    public function get_customerresults($search_term2, $limit ,$offset)
    {
        // Use the Active Record class for safer queries.
        $this->db->select('*');
        $this->db->from('customers');
        $this->db->like('name',$search_term2);
        $this->db->limit($limit, $offset);
        // Execute the query.
        $query = $this->db->get();

        // Return the results.
        return $query->result_array();
    }

    public function get_orderresults($conditions = array(), $limit ,$offset)
    {
        // Use the Active Record class for safer queries.
        //print_r($conditions); die();
        // $this->db->select('*');
        // $this->db->from('order');
        $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
        $this->db->from('order');
        $this->db->join('customers', 'order.customer_id = customers.id'); 
        //$this->db->like('addedDate',$conditions);
        $this->db->limit($limit, $offset);
        // Execute the query.
        if (isset($conditions['start_date']) && isset($conditions['end_date'])) {
            if($conditions['start_date'] != "" && $conditions['end_date'] != ""){
                $this->db->where('order.addedDate BETWEEN "'. date('Y-m-d', strtotime($conditions['start_date'])). '" and "'. date('Y-m-d', strtotime($conditions['end_date'])).'"');
            }
        }
        
        $this->db->order_by('id', 'desc');
        
        return $this->db->get();

        //$query = $this->db->get();

        // Return the results.
        return $query->result_array();
    }
/*-------------------COUNT TOTAL SEARCH DATEWISE ORDER---------*/

   public function count_date_orderresults($conditions = array())
    {
        
        $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
        $this->db->from('order');
        $this->db->join('customers', 'order.customer_id = customers.id'); 
        //$this->db->like('addedDate',$conditions);
        // Execute the query.
        
        if (isset($conditions['start_date']) && isset($conditions['end_date'])) {
            if($conditions['start_date'] != "" && $conditions['end_date'] != ""){
                $this->db->where('order.addedDate BETWEEN "'. date('Y-m-d', strtotime($conditions['start_date'])). '" and "'. date('Y-m-d', strtotime($conditions['end_date'])).'"');
            }
        }
        
        $query = $this->db->get();

        // Return the results.
        return $query->num_rows(); 
    }

    public function getorderByordernumber($search_term, $limit ,$offset)
    {
        // Use the Active Record class for safer queries.
        $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
        $this->db->from('order');
        $this->db->join('customers', 'order.customer_id = customers.id'); 
        $this->db->like('order.order_number',$search_term);
        $this->db->limit($limit, $offset);
        // Execute the query.
       return $query = $this->db->get();
//print_r($query); die();
        // Return the results.
        // return $query->result_array();
    }

   public function count_searchordernumber($search_term)
    {
        
        $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
        $this->db->from('order');
        $this->db->join('customers', 'order.customer_id = customers.id'); 
        $this->db->like('order.order_number',$search_term);
        // Execute the query.
        $query = $this->db->get();
        // Return the results.
        return $query->num_rows();
        //print_r($r); die();
    }

}
