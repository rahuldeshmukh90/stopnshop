<?php

/**
* 
*/
class gas_model extends CI_Model
{
	
	function __construct()
	{
		# code...
	}

	function get_gas_detail(){

            $query = $this->db-> get('sa_gas');
            return $query;

           // print_r($query); die();
 

        }
    function get_gas_row($id)  
        {  

            $query = $this->db->get_where('sa_gas', array('id'=>$id));
            return $query->row();
    
       } 

    function update_gas_detail()  
        {  

           $data = array( 
                            //'id'        => $this->input->post('id'),  
                            'name'      => $this->input->post('name'),
                            'price'      => $this->input->post('price'),
                            'addedDate'  => date("Y-m-d h:i:s")
                            
                   ); 
         
                //print_r($data); die();
                     
                      $this->db->where('id',$this->input->post('id')); 
                      $query = $this->db->update('sa_gas',$data);

                      if ($query) {
                         return true;

                       } else{

                         return false;
                       }

                    
                      
       }     

   }