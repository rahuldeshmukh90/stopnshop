<?php
 
 /**
 * 
 */
 class Category_model extends CI_Model
 {
 	
 	function __construct()
 	{
 		# code...
 	}
 	function all_categorys(){

            $query = $this->db-> get('sa_category');
            return $query;
    }

    function add_category(){

                $f_name = $_FILES['image']['name'];
                $f_tmp = $_FILES['image']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile="";
                if($f_name){
                $f_newfile = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }


               // echo $f_newfile ; die();

     $data = array(  
                            'name' => $this->input->post('name'),  
                            'description' => $this->input->post('description'),  
                            'image' => $f_newfile

                             
                   );

                          return   $this->db->insert('sa_category',$data);    

    }

    function get_category($id)  
        {  
            
        	$query = $this->db->get_where('sa_category', array('id'=>$id));
            return $query->row();
                      
       }
   function get_category_id()  
        {  
        return $query = $this->db->query("SELECT * FROM sa_category");

 
                      
      }

    function update_category()  
        {

                //  $f_name = $_FILES['image']['name'];
                // $f_tmp = $_FILES['image']['tmp_name'];
                // $f_extension = explode('.',$f_name); //To breaks the string into array
                // $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                // $f_newfile="";
                // if($f_name){
                // $f_newfile1 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                // $store = "upload/" . $f_newfile1;
                // $file1 =  move_uploaded_file($f_tmp,$store);
                // }

  if(empty($_FILES['image']['name']))
{
   $f_newfile01 = $this->input->post('old_images'); 
}else{
    //echo"up"; die();
                $f_name = $_FILES['image']['name'];
                $f_tmp = $_FILES['image']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile01 ="";
                if($f_name){
                $f_newfile01 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile01;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
}        
        	
           $data = array( 
                            'id' => $this->input->post('id'),  
                            'name' => $this->input->post('name'),  
                            'image' => $f_newfile01,
                            'description' => $this->input->post('description')  
                            //'keyword' => $this->input->post('keyword'),
                   ); 
         

             //print_r($data); die();        
                      $this->db->where('id',$this->input->post('id')); 
                      $query = $this->db->update('sa_category',$data);

                      if ($query) {
                          return true ;
                      }else{
                          return false ;
                      }

                    
                      
       }

    function delete($id)  
        {  
            
            $data = array(  
                            'id' => $id,
                         );
        
           $query = $this->db->delete("sa_category", $data);  

           return $query;
      
        } 
    
     function get_info($id)
    {
        $query = $this->db->get_where('sa_category',array('name' => $id));
        
        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return $this->get_empty_object('sa_category');
        }
    }  

    function get_empty_object($table_name)
    {   
        $obj = new stdClass();
        
        $fields = $this->db->list_fields($table_name);
        foreach ($fields as $field) {
            $obj->$field = '';
        }
        return $obj;
    }      
      
 }
