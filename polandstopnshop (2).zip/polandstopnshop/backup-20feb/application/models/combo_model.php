<?php

class Combo_model extends CI_Model
{
	
	function __construct(){
        
		# code...
	}

	function getcombolist($limit, $offset){

     $this->db->where('product_type','combo');
     $this->db->limit($limit, $offset);
     $query = $this->db-> get('sa_products');
     return $query;

           // print_r($query); die();
    }

    function save_and_get_id(&$data, $id=false)
	{
		
		if ($this->db->insert('sa_products' ,$data)) {
			return $data['id'] = $this->db->insert_id();
				
		}
		return false;
	}

	function update_and_get_id(&$data, $comboid)
	{
		$this->db->where('id',$comboid); 
        $query = $this->db->update('sa_products',$data);
        return $query;
	}

	function save_combo_details(&$data, $id=false)
	{
		
		if ($this->db->insert('deal_detail',$data)) {
			return $data['id'] = $this->db->insert_id();
		}
		return false;
	}

	function delete($id)  
        {  
            
            $data = array(  
                            'id' => $id,
                         );
        
           $query = $this->db->delete("sa_products", $data);  

           return $query;
      
        }

    function get_product_by_id($id){

            $query = $this->db->get_where('sa_products', array('id'=>$id));
            return $query->row();

    }

    function get_productdetail_by_id($id){

            // $query = $this->db->get_where('deal_detail', array('id'=>$id));
            // return $query;

            $this->db->select('*');
            $this->db->from('deal_detail');
            $this->db->where('dealId',$id);
            return $query=$this->db->get();

    } 

    function get_combo_row($id)  
        {  
            
        	$query = $this->db->get_where('sa_products', array('id'=>$id));
            return $query->row();
            return $row_id = $query->row('id');
                      
       }
    
    function update_combo_details(&$data, $id=false)
	{
		

		//print_r($id); die();


		$this->db->where('id',$id); 
        $query = $this->db->update('deal_detail',$data);

		// if ($this->db->insert('sa_products' ,$data)) {
		// 	return $data['id'] = $this->db->insert_id();
				
		// }
		 return false;
	}

	function total_combo_product()  
        {  
           
            $this->db->select('count(*)');
            $this->db->where('product_type' ,'combo');
            $query = $this->db->get('sa_products');
            $cnt   = $query->row_array();
            return $cnt['count(*)']; 
                      
       }
          

}