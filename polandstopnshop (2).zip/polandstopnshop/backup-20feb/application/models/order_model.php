<?php

/**
* 
*/
class Order_model extends CI_Model
{
	
	function __construct(){
        
		# code...
	}
    function getlatestOrder(){

       	//   $this->db->select('*');
		      // $this->db->order_by('id', 'DESC');  
		      // $this->db->from('order');
          $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
          $this->db->order_by('id', 'DESC');  
          $this->db->from('order');
          $this->db->join('customers', 'order.customer_id = customers.id');
		      $this->db->limit('10');
		      // $this->db->where(array('checklist_item_id' => $id, 'status' => 1));
          $query = $this->db->get();
		      //print_r($query); die();
		      return $query->result_array();  

	}


  function get_order_by_id($id){


            $this->db->select('*');
            $this->db->from('order');
		        $this->db->join('customers', 'order.customer_id = customers.id');
		        $this->db->where('order.id' ,$id);
            $query = $this->db->get(); 
            //$query = $this->db->get_where('order', array('id'=>$id));
            return $query->row();

   }

  function getOrderdetail($id){

       	  $this->db->select('*');
		      //$this->db->order_by('id', 'DESC');  
		      $this->db->from('order_detail');
		      $this->db->join('sa_products', 'order_detail.product_id = sa_products.id');
		      //$this->db->limit('5');
		      // $this->db->where(array('checklist_item_id' => $id, 'status' => 1));
		      $this->db->where('order_id' ,$id);
          $query = $this->db->get();
		      //print_r($query); die();
		      return $query->result_array();  

	}
/*----------------GET ALL ORDER ------------------*/
 
   function get_order($limit, $offset){

    $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
    $this->db->from('order');
    $this->db->join('customers', 'order.customer_id = customers.id');
    $this->db->limit($limit, $offset);
    return $query = $this->db->get();  

   } 

   function total_order()  
        {  
           
            $this->db->select('count(*)');
            $query = $this->db->get('order');
            $cnt = $query->row_array();
            return $cnt['count(*)'];                      
       }

 /*-------------get order by using id---------------------------*/
 
 // function get_order_by_id($id){

 //        $query = $this->db->get_where('order', array('id'=>$id));
 //        return $query->row();

 //    }

 //    function get_orderdetail_by_id($id){

 //            $this->db->select('*');
 //            $this->db->from('deal_detail');
 //            $this->db->where('dealId',$id);
 //            return $query=$this->db->get();

 //    }

/*----------GET WEEKLY REPORT OF ORDER--------------------------*/


    function weeklyorder($limit, $offset){

          $start_date = date("Y-m-d 00:00:00", strtotime("-1 week"));

          $end_date   = date("Y-m-d 59:59:59");

          $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
          $this->db->from('order');
          $this->db->join('customers', 'order.customer_id = customers.id'); 

          $this->db->where("order.addedDate >= '" . $start_date . "' AND order.addedDate <= '" . $end_date . "'");

         $this->db->limit($limit, $offset);
         $query = $this->db->get();
         if($query->num_rows()>0){

            return $query;

         }else{

            return false;
         } 

        }

/*----------COUNT WEEKLY REPORT OF ORDER--------------------------*/


    function total_weeklyorder(){
    	    
    	  
          $start_date = date("Y-m-d 00:00:00", strtotime("-1 week"));

          $end_date   = date("Y-m-d 59:59:59");

          //$this->db->from('order');
          //$this->db->select('count(*)');
          $this->db->select('count(*)');
          $this->db->from('order');
          $this->db->join('customers', 'order.customer_id = customers.id');  

          $this->db->where("order.addedDate >= '" . $start_date . "' AND order.addedDate <= '" . $end_date . "'");
          $query = $this->db->get();

          $cnt = $query->row_array();
          return $cnt['count(*)'];

        }  

/*----------GET MONTHLY REPORT OF ORDER--------------------------*/


    function monthlyorder($limit, $offset){

          $start_date = date("Y-m-d 00:00:00", strtotime("-1 month"));

          $end_date   = date("Y-m-d 59:59:59");

          $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
          $this->db->from('order');
          $this->db->join('customers', 'order.customer_id = customers.id'); 

          $this->db->where("order.addedDate >= '" . $start_date . "' AND order.addedDate <= '" . $end_date . "'");

         $this->db->limit($limit, $offset);
         $query = $this->db->get();
         if($query->num_rows()>0){

            return $query;

         }else{

            return false;
         } 

        }  

/*----------COUNT MONTHLY REPORT OF ORDER--------------------------*/


    function total_monthlyorder(){
          
        
          $start_date = date("Y-m-d 00:00:00", strtotime("-1 month"));

          $end_date   = date("Y-m-d 59:59:59");

          //$this->db->from('order');
          //$this->db->select('count(*)');
          $this->db->select('count(*)');
          $this->db->from('order');
          $this->db->join('customers', 'order.customer_id = customers.id');  

          $this->db->where("order.addedDate >= '" . $start_date . "' AND order.addedDate <= '" . $end_date . "'");
          $query = $this->db->get();

          $cnt = $query->row_array();
          return $cnt['count(*)'];

        }

/*----------GET YEARLY REPORT OF ORDER--------------------------*/


    function yearlyorder($limit, $offset){

          $start_date = date("Y-m-d 00:00:00", strtotime("-1 year"));

          $end_date   = date("Y-m-d 59:59:59");

          $this->db->select('order.* ,customers.id as cusid ,customers.name ,customers.lastName');
          $this->db->from('order');
          $this->db->join('customers', 'order.customer_id = customers.id'); 

          $this->db->where("order.addedDate >= '" . $start_date . "' AND order.addedDate <= '" . $end_date . "'");

         $this->db->limit($limit, $offset);
         $query = $this->db->get();
         return $query;


        }  

/*----------COUNT MONTHLY REPORT OF ORDER--------------------------*/


    function total_yearlyorder(){
          
        
          $start_date = date("Y-m-d 00:00:00", strtotime("-1 year"));

          $end_date   = date("Y-m-d 59:59:59");

          //$this->db->from('order');
          $this->db->select('count(*)');
          $this->db->from('order');
          $this->db->join('customers', 'order.customer_id = customers.id');  
          $this->db->where("order.addedDate >= '" . $start_date . "' AND order.addedDate <= '" . $end_date . "'");
          $query = $this->db->get();

          $cnt = $query->row_array();
          return $cnt['count(*)'];

        }  


}