<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">

  <div class="page-header">
         
     <div class="container-fluid">
      <br />
      
      <h1>Request Detail</h1>
      
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="">Request Detail</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i>Request Detail</h3>
      </div>
      <div class="panel-body">
       
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">


            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  
                  <td class="text-center"> 
                      Product Image
                  </td>
                  <td class="text-center">
                      Product Name
                  </td>
                  <td class="text-center">
                      Product Details 
                  </td>
                   <td class="text-center">
                      UBS Code  
                  </td>
                  <td class="text-center">
                      Date 
                  </td>
                  
                 
                  <!-- <td class="text-right">Action</td> -->
                </tr>
              </thead>
              <tbody>

                
                       <?php  
         foreach ($request->result() as $get_request)  
         { 
  ?>
      
                <tr>
                    <td class="text-center">  
			                   <img style="width: 90px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $get_request->product_image;?>"  alt="image"   class="img-thumbnail" />

							      </td>
                    <td class="text-center"><?php echo $get_request->product_name;?></td>
                        
                    <td class="text-center"><?php echo $get_request->product_details;?></td>
                    <td class="text-center"><?php echo $get_request->ubs_code;?></td>
                    <td class="text-center"><?php echo $get_request->addedDate;?></td>
                    <!-- <td class="text-right">

                      <?php echo anchor("gas/update_gasview/$get_request->id",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary'])?>

                   </td> -->
                </tr>

              
<?php } ?>

              </tbody>
            </table>
    <?php echo $this->pagination->create_links(); ?>         
          </div>
        </form>
      </div>
    </div>
  </div>
 </div>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
