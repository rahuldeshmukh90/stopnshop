<?php $this->load->view('template/head'); ?>

<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>
<div id="content">
    <div class="page-header">

           
        <div class="container-fluid">
            <h1>Categories</h1>                
        </div>

        <div class="container-fluid">
           
           <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('categories/category_list'); ?>">Category</a></li>
                <li><a href="">Add Category</a></li>
              </ul>
                        
        </div>

    </div>

  




  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Add Category</h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo site_url('categories/add_category'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Product Details</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">
                                <div class="" id="">

                
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Category Name</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="name"  placeholder="category Name" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-image">Category image</label>
                    
                    <div class="col-sm-10">

                      <input type="file" name="image"  />
                    </div>

                  </div>

                  <div class="form-group required">

                    <label class="col-sm-2 control-label" for="input-description">Description</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="description"  placeholder="Category Description" class="form-control" />
                    </div>

                  </div>

             <!--     
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-keyword">keyword</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="keyword" value="" placeholder="Category keyword" class="form-control" />
                    </div>

                  </div> -->
                 

                

                  <div class="form-group">
                  
                    
                    <div class="col-sm-10">
                     <input type="submit" value="Add Category" class="btn btn-primary">

                     <a class="btn btn-default" href="<?php echo site_url('categories/category_list'); ?>">Cancel</a>
                    </div>
                  </div>
                 

              
                </div>
                               
              </div>
            </div>


        
            <div class="tab-pane" id="tab-image">
              <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                  <thead>
                    <tr>
                      <td class="text-left">Image</td>
                    </tr>
                  </thead>
                  
                  <tbody>
                    <tr>
                      <td class="text-left"><a href="" id="thumb-image" data-toggle="image" class="img-thumbnail"><img src="http://localhost/open/image/cache/no_image-100x100.png" alt="" title="" data-placeholder="http://localhost/open/image/cache/no_image-100x100.png" /></a><input type="hidden" name="image" value="" id="input-image" /></td>
                  </tr>
                  </tbody>
                </table>
              </div>
              <div class="table-responsive">
                <table id="images" class="table table-striped table-bordered table-hover">
                  <thead>
                    <tr>
                      <td class="text-left">Additional Images</td>
                      <td class="text-right">Sort Order</td>

                    <!-- Product Rotator -->
                    <td class="text-center">Is Rotator Image</td>
                
                      <td></td>
                    </tr>
                  </thead>
                  <tbody>
                                                          </tbody>
                  <tfoot>
                    <tr>
                      <td colspan="2"></td>
                      <td class="text-left"><button type="button" onclick="addImage();" data-toggle="tooltip" title="Add Image" class="btn btn-primary"><i class="fa fa-plus-circle"></i></button></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
 <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    name: "required",
                    description: "required",
                    image: "required",
                   
                   
                },
                messages: {
                    name: "<P class='text-danger'>Please enter your name</p>",
                    description: "<P class='text-danger'>please fill description input</p>",
                    image: "<P class='text-danger'>please select image</p>",
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>
</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
