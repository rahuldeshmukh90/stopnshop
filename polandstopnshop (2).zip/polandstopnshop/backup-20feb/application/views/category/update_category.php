<?php $this->load->view('template/head'); ?>

<body>
<div id="container">
<?php  $this->session->userdata('id'); ?>
<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/left_sidebar'); ?>
<div id="content">
  <div class="page-header">
       <div class="container-fluid">
      <h1>Categories</h1>
      
    </div>
     <div class="container-fluid">
     
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('categories/category_list'); ?>">Category</a></li>
                <li><a href="">Edit Category</a></li>
              </ul>
    </div>
  
  </div>




  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Edit Category</h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo site_url('categories/edit_category'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Product Details</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">
                                <div class="" id="">

                
                  <div class="form-group required">
                    <input type="hidden" name="id"  value="<?php echo $category->id;?>" class="form-control" />
                    <label class="col-sm-2 control-label" for="input-name1">Category Name</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="name"  value="<?php echo $category->name;?>" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-image">Change image</label>
                    <div class="col-sm-10">

                      <img src="<?php echo base_url();?>upload/<?php echo $category->image;?>" width="80" height="100" alt="Armchair" class="img-thumbnail" />
                    </div>
                    <label class="col-sm-2" for="input-image"></label>
                    <div class="col-sm-10">
                        <input type="file" name="image"  />
                      <input type="hidden" name="old_images" value="<?php echo $category->image;?>"/>

                    </div>

                    

                  </div>

                  <div class="form-group required">

                    <label class="col-sm-2 control-label" for="input-description">Description</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="description"  value="<?php echo $category->description;?>" class="form-control" />
                    </div>

                  </div>

                 
                 <!--  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-keyword">keyword</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="keyword" value="" placeholder="Category keyword" class="form-control" />
                    </div>

                  </div> -->
                 

                

                  <div class="form-group">
                  
                    
                    <div class="col-sm-10">
                    <input type="submit" value="Edit Category" class="btn btn-primary">

                    <a class="btn btn-default" href="<?php echo site_url('categories/category_list'); ?>">Cancel</a>
                    </div>
                  </div>
                </div>               
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
 <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    name: "required",
                    description: "required",
                   
                   
                   
                },
                messages: {
                    name: "<P class='text-danger'>Please enter your name</p>",
                    description: "<P class='text-danger'>please fill description input</p>",
                    
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>



</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
