<?php $this->load->view('template/head'); ?>
<body>
    <link href="http://localhost/mangatrai/auth/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
    
    <!-- <script src="http://localhost/mangatrai/auth/js/bootstrap.min.js"></script> -->
    
    
    <!-- <script src="http://localhost/mangatrai/auth/js/bootstrap-datetimepicker.min.js"></script> -->
    
    

<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar.php'); ?>

<div id="content">

                               <?php if($this->session->flashdata('message')): ?>
                                
                                   
                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"> 
                                       <?php echo $this->session->flashdata('message');?></a>
                                    </div>  
                              <?php endif;?> 
   
     

                              <?php if($this->session->flashdata('success')): ?>
                                
                                   
                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('success');?></a>
                                    </div>                                   
                                  
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('error')):?>
                                  
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('error');?></a>
                                        </div>
                                       
                                    
                                <?php endif;?>



                              <?php if($this->session->flashdata('w_success')): ?>
                                <ul class="woocommerce-message">
                                  <li>

                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_success');?></a>
                                    </div>
                                   
                                                                        
                                  </li>
                                </ul>
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('w_error')):?>
                                    <ul class="woocommerce-error">
                                      <li>
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_error');?></a>
                                       </div>
                                        
                                      </li>
                                    </ul>
                              <?php endif;?>
  <div class="page-header">
      <div class="container-fluid">
      
      <h1>Orders</h1>
              
    </div>
     <div class="container-fluid">
      <div class="pull-right">

     
      <!-- <a href="<?php echo site_url('combo/addcomboView'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-primary"><i class="fa fa-plus"></i> Add Combo Products</a> -->

      <!-- <a href="<?php echo site_url('products/import_view'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-primary"><i class="fa fa-plus"></i> Add CSV</a> -->
        
        
      </div>
      
              <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="">Orders</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i>Order List</h3>
       
      </div>



      <div class="panel-body">


        
           <div class="row" style="margin-bottom: 20px;">
           	<div class="col-sm-2">
              <a href="<?php echo site_url('order/weeklyorderreport'); ?>">
                     <button class="btn btn-info">LAST 1 WEEK</button>
              </a>
           	</div>
           	<div class="col-sm-2">
              <a href="<?php echo site_url('order/monthlyorderreport'); ?>">
           		       <button class="btn btn-info">LAST 1 MONTH</button>
              </a>       
           	</div>
           	<div class="col-sm-2">
              <a href="<?php echo site_url('order/yearlyorderreport'); ?>">
           		      <button class="btn btn-info">LAST 1 YEAR</button>
              </a>
           	</div>
              <div class="col-sm-5">
              <form id="add_form" action="<?php echo site_url('search_item/searchbyorderNumber') ?>" method="post" role="search" >
              <div class='col-sm-9' style="padding-right: 0px">
                  
                      
                <input type='text' id="ordernumber" name="ordernumber" class="form-control" placeholder="Search By Order Number" />
                          
              </div>
              <div class='col-sm-2' style="padding-left: 0px">
                  <div class='input-group date'>
                      <input type='submit' class="form-control" value="SEARCH"/>
                  </div>
              </div>
            </form>
            </div>
          </div>

            <div class="row">
               <form id="add_form1" action="<?php echo site_url('search_item/search_date') ?>" method="post" role="search" >
              <div class='col-sm-2'>
                  
                      <div class='input-group date' id='datetimepicker1'>
                          <input type='text' id="start_date" name="start_date" class="form-control" placeholder="Start Date" />
                          <span class="input-group-addon">
                              <span class="glyphicon glyphicon-calendar"></span>
                          </span>
                      </div>
                  
              </div>
              <div class='col-sm-2'>
                  
                      <div class='input-group date' id='datetimepicker2'>
                          <input type='text' id="end_date" name="end_date" class="form-control" placeholder="End Date" />
                          <span class="input-group-addon">
                              <span class="glyphicon glyphicon-calendar"></span>
                          </span>
                      </div>
                  
              </div>
              <div class='col-sm-2'>
                  
                      <div class='input-group date'>
                          <input type='submit' class="form-control" value="SEARCH"/>
                      </div>
                  
              </div>
            </form>
          </div> 
         
         <!--  <div class="row">
            <form action="<?php echo site_url('search_item/search_date') ?>" method="post" role="search" >
              <div class='col-sm-2'>
                  <div class="form-group">
                      <div class='input-group date' id='datetimepicker1'>
                          <input type='text' name="start_date" class="form-control" placeholder="Start Date" />
                          <span class="input-group-addon">
                              <span class="glyphicon glyphicon-calendar"></span>
                          </span>
                      </div>
                  </div>
              </div>
              <div class='col-sm-2'>
                  <div class="form-group">
                      <div class='input-group date' id='datetimepicker2'>
                          <input type='text' name="end_date" class="form-control" placeholder="End Date" />
                          <span class="input-group-addon">
                              <span class="glyphicon glyphicon-calendar"></span>
                          </span>
                      </div>
                  </div>
              </div>
              <div class='col-sm-2'>
                  <div class="form-group">
                      <div class='input-group date'>
                          <input type='submit' class="form-control" value="SEARCH"/>
                      </div>
                  </div>
              </div>
            </form>  
              
          </div> -->

           

        <div style="margin-top: 10px">
       
          
        </div>
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  
                  <!-- <td style="width: 1px;" class="text-center"><input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);" /></td> -->


                  <td class="text-center">Order NO.</td>
                  <td class="text-left"> 
                      Customer Name
                  </td>
                  <td class="text-left">
                      Total Item
                  </td>
                  <td class="text-left"> 
                      Price
                  </td>
                 
                  <td class="text-left"> 
                      Date
                  </td>
                 
                  <td class="text-right">Action</td>
                </tr>
              </thead>
              <tbody>
                                              
      <?php

      if(!empty($list)){ 
      foreach ($list->result() as $order) { ?>

                <tr>
                    <td class="text-center">
                       <!-- <img src="<?php echo base_url();?>upload/<?php echo $products->image;?>" alt="" class="img-thumbnail" style="width:80px; height:80px"/> -->
                       <?php echo $order->order_number;?>
                    </td>
                    <td class="text-left"><?php echo $order->name." ".$order->lastName;?></td>
                    <td class="text-left"><?php echo $order->total_items;?></td>
                    <td class="text-left">
                          <!-- <span style="text-decoration: line-through;">100.0000</span> -->

                          <br/>

                          <div class="text-danger"><?php echo $order->total_items;?></div>

                    </td>
                    <td class="text-left"><?php echo $order->addedDate;?></td>

                    <td class="text-right"> <a href=""><?php echo anchor("order/orderdetail/$order->id",'view more',['class'=>'btn btn-info'])?></a></td>

                    <!-- <td>

                    <?php echo anchor("combo/editcomboview/$order->id",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary'])?>

                    <?php echo anchor("combo/delete_combodeal/$order->id",'<i class="fa fa-close"></i>',['class'=>'btn btn-danger', 'onClick'=>"return doconfirm();"])?>

                    
                    </td> -->
                </tr>
            <?php } }else{ ?>
                  <tr>
                      <td colspan="6"><?php echo "No Data"; ?></td>
                  </tr>

            <?php } ?>
                       
              </tbody>
            </table>
		<?php echo $this->pagination->create_links();?>
          </div>
        </form>

      </div>
    </div>
  </div>
  <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                          ordernumber: "required"
                          
                },
                messages: {
                    
                    ordernumber: "<P>Text is empty</p>"
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>

<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form1").validate({
                rules: {
                          start_date: "required",
                          end_date: "required"
                },
                messages: {
                    
                    start_date: "<P>Enter Start Date</p>",
                    end_date: "<P>Enter End Date</p>"
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>

 
              <script type="text/javascript">
                  $(function () {
                      $('#datetimepicker1').datetimepicker();
                  });
              </script>

              <script type="text/javascript">
                  $(function () {
                      $('#datetimepicker2').datetimepicker();
                  });
              </script>
 </div>
<footer id="footer"><a href="">Shop App</a> &copy; 2017-2018 All Rights Reserved.</footer></div>
</body>
</html>
