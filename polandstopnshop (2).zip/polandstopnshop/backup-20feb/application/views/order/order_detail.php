<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->load->view('template/header'); ?>
<?php  $this->load->view('template/left_sidebar'); ?>

<div id="content">

  <div class="page-header">
        
     <div class="container-fluid">
      <br />
      
      <h1>Order</h1>
      
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="">Order Detail</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i>Order Detail</h3>
      </div>
      <div class="panel-body">
        <div class="col-sm-4">
          
          <img width="100%" class="img-responsive" src="<?php echo base_url();?>upload/order.jpg"  alt="image" />
        </div> 
        <div class="col-sm-8">
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <div class="col-sm-12"><h1 class="text-center"><?php echo $order->order_number;?></h1></div> 

            <table class="table">
             
              <tbody>
                <tr>
                    <td class="text-left" colspan="1"><b>Customer Name</b></td>
                    <td class="text-left" colspan="5" ><?php echo $order->name." ".$order->lastName;?></td>    
                </tr>
                <tr>
                    <td class="text-left" colspan="1"><b>Mobile Number</b></td>
                    <td class="text-left" colspan="5" ><?php echo $order->contact; ?></td>    
                </tr>
                <tr>
                    <td class="text-left" colspan="1"><b>Email Address</b></td>
                    <td class="text-left" colspan="5" ><?php echo $order->email; ?></td>    
                </tr>
                 <tr>
                    <td class="text-left"><b>Order  Number</b></td>
                    <td class="text-left" colspan="5" ><?php echo $order->order_number;?></td>    
                </tr>
             
                <tr>
                    <td class="text-left" colspan="1"><b>Total Item's</b></td>
                    <td class="text-left" colspan="5" ><?php echo $order->total_items;?></td>    
                </tr>

                <tr>
                    <td class="text-left" colspan="1"><b>Total Price</b></td>
                    <td class="text-left" colspan="5" ><?php
                     $totalprice = $order->amount;
                     //echo $totalprice;
                     echo number_format($totalprice,2); 
                     ?></td>    
                </tr>
                <!--<tr>
                    <td class="text-left" colspan="1"><b>Quantity</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->qnty;?> , </td>    
                </tr>-->
                 <tr>
                    <td class="text-left" colspan="1"><b>Date</b></td>
                    <td class="text-left" colspan="5" ><?php echo $order->addedDate;?></td>    
                </tr>
              </tbody>
            </table>
          </div>
        </form>
       </div> 
      </div>
      <div class="col-sm-12">
           <div class="panel-heading">
        <h3 class="panel-title">Order Detail</h3>
      </div>
      <table class="table">
              
              <tr style="background:indianred">
                <th>PRODUCT IMAGE</th>
                <th>PRODUCT NAME</th>
                <th>QUANTITY</th>
                <th>PRICE</th>
                <th>STATUS</th>
                <th>DESCRIPTION</th>
              </tr>
              <tbody>
                <?php foreach ($order_detail as $order_details) { ?>   
                <tr>
                  <td>
                     <img src="<?php echo base_url();?>upload/<?php echo $order_details['image'];?>" alt="" class="img-thumbnail" style="width:70px; height:60px"/>
                   </td>
                  <td><?php echo $order_details['name']; ?></td>
                  <td><?php echo $order_details['total_item']; ?></td>
                  <td><?php
                   $price = $order_details['amount'];
                   echo number_format($price ,2);
                    ?>

                 </td>
                 <td>Pendding</td>
                  <td><?php echo $order_details['description']; ?></td>
                </tr>
                <?php } ?>
              </tbody>
      </table>          
      </div>
    </div>
  </div>
 </div>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
