<?php

if (isset['upload'])

 {
    echo "1";
}else{
     echo "0";
}
?>
<?php 
 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo_data";
 
// Create connection
 
//mysql_connect($servername, $username, $password, $dbname);
$dbhandle = mysql_connect($servername,$username,$password) or die("unable to connect to mysql");
//select a database to work with
$selected = mysql_select_db($dbname,$dbhandle) or die("Could not select database.");

// Check connection

echo "connected";
 
use Box\Spout\Reader\ReaderFactory;
use Box\Spout\Common\Type;
 
// Include Spout library 
require_once 'spout-2.4.3/src/Spout/Autoloader/autoload.php';
 
// check file name is not empty
if (!empty($_FILES['file']['name'])) {

    // Get File extension eg. 'xlsx' to check file is excel sheet
    $pathinfo = pathinfo($_FILES["file"]["name"]);
     
    // check file has extension xlsx, xls and also check 
    // file is not empty
   if (($pathinfo['extension'] == 'xlsx' || $pathinfo['extension'] == 'xls') 
           && $_FILES['file']['size'] > 0 ) {
         
        // Temporary file name
        $inputFileName = $_FILES['file']['tmp_name']; 
    
        // Read excel file by using ReadFactory object.
        $reader = ReaderFactory::create(Type::XLSX);
 
        // Open file
        $reader->open($inputFileName);
        $count = 1;
 
        // Number of sheet in excel file
        foreach ($reader->getSheetIterator() as $sheet) {
             
            // Number of Rows in Excel sheet
            foreach ($sheet->getRowIterator() as $row) {
 
                // It reads data after header. In the my excel sheet, 
                // header is in the first row. 
                if ($count > 1) { 
 
                    // Data of excel sheet
                    $data['name'] = $row[0];
                    $data['email'] = $row[1];
                    $data['phone'] = $row[2];
                    $data['city'] = $row[3];

                    $name = $data['name'];
                    $email = $data['email'];
                    $phone = $data['phone'];
                    $city = $data['city'];
                     
                    //Here, You can insert data into database. 
                    //print_r($data);
                    // echo $name; die();

                    $sql = "INSERT INTO `excel_data`(`name`, `email`, `phone`, `city`) VALUES ('$name','$email','$phone','$city')";

                    $query = mysql_query($sql) or die(mysql_error());

                    if (mysql_affected_rows()>0) {
                        echo 'data insert successfully';
                    }else{
                        echo 'error in inserting data';
                    }
                }
                $count++;
            }
        }
 
        // Close excel file
        $reader->close();
 
    } else {
 
        echo "Please Select Valid Excel File";
    }
 
} else {
 
    echo "Please Select Excel File";
     
}
?>