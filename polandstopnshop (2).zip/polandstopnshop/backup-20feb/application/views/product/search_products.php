<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <div class="pull-right">


      <a href="<?php echo site_url('products/add_products_view'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-primary"><i class="fa fa-plus"></i> Add Products</a>
        
       <a href="<?php echo site_url('products/import_view'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-primary"><i class="fa fa-plus"></i> Add CSV</a>   
      </div>
              <h1>Search Products</h1>
    </div>
    <div class="container-fluid">
    
              <ul class="breadcrumb">
                <li><a href="">Home</a></li>
                <li><a href="">Search Products</a></li>
              </ul>
    </div>
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i> Product List</h3>
       
      </div>



      <div class="panel-body">


        
          <div class="row">
            <div class="col-sm-12" style="margin-bottom: 5px;margin-right: 10px" >

      <form class="navbar-form navbar-right" action="<?php echo site_url('search_item/search_products') ?>" method="post" role="search">
        <div class="form-group">
          <input class="form-control" name="search" id="search" placeholder="Search" type="text">
          <input type="hidden" value="search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
             
                <!-- <form action="<?php echo site_url('search_item/search_products') ?>" method="post">
               <!--  <span class="icon text-right"><i class="fa fa-search"></i></span> -
                    <input type="text" name="search" id="search" class="pull-right" placeholder="Search Here . . .">
                    <input type="hidden" value="search">
                </form>    -->      
            </div>
         
          </div>
        


        <div>
       
          
        </div>
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  
                  <!-- <td style="width: 1px;" class="text-center"><input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);" /></td> -->


                  <td class="text-center">Image</td>
                  <td class="text-left"> 
                      Product Name
                  </td>
                  <td class="text-left"> 
                      Category
                  </td>
                  <td class="text-left">
                      Description
                  </td>
                  <td class="text-left"> 
                      Price
                  </td>
                 
                 <!--  <td class="text-left">
                      Meta Description 
                  </td> -->
                  <td class="text-left">Action</td>
                </tr>
              </thead>
              <tbody>
                                              
              <?php  

         foreach ($results as $products) { 
               ?>
                <tr>
                    <!-- <td class="text-center">     
                       <input type="checkbox" name="selected[]" value="42" />
                    </td> -->
                    <td class="text-center">
                       <img src="<?php echo base_url();?>upload/<?php echo $products['image'];?>" alt="" class="img-thumbnail" style="width:150px;height:80px"/>
                    </td>
                    <td class="text-left"><?php echo $products['name']; ?></td>
                    <td class="text-left">category</td>
                    <td class="text-left"><?php echo $products['description'];?></td>
                    <td class="text-left">
                          <!-- <span style="text-decoration: line-through;">100.0000</span> -->

                          <br/>

                          <div class=""><?php echo $products['price'];?></div>

                    </td>
                    
                    <td>

                    <?php echo anchor('products/edit_form_view/'.$products["id"],'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary'])?>

                     <?php echo anchor('products/delete_product/'.$products["id"],'<i class="fa fa-close"></i>',['class'=>'btn btn-danger'])?>

                   <!--  <a href="<?php ; ?>" title="Edit"   class="btn btn-primary text-left"><i class="fa fa-pencil"></i></a> -->
                    
                  <!--    <a href="<?php echo base_url('index.php/admin_login/delete_product/$products->id'); ?>" title="delete" class="btn btn-danger text-right"><i class="fa fa-close"></i></a> -->
                    
                    </td>
                </tr>

              <?php } ?>
                       
              </tbody>
            </table>
            
             <?php echo $this->pagination->create_links(); ?>
           <!--  <?php 	 { ?> 

            	<h5> There Are No Products </h5>
            	
          <?php  } ?> -->
          </div>
        </form>
      </div>
    </div>
  </div>
  <script type="text/javascript"><!--
$('#button-filter').on('click', function() {
	var url = 'index.php?route=catalog/product&token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq';

	var filter_name = $('input[name=\'filter_name\']').val();

	if (filter_name) {
		url += '&filter_name=' + encodeURIComponent(filter_name);
	}

	var filter_model = $('input[name=\'filter_model\']').val();

	if (filter_model) {
		url += '&filter_model=' + encodeURIComponent(filter_model);
	}

	var filter_price = $('input[name=\'filter_price\']').val();

	if (filter_price) {
		url += '&filter_price=' + encodeURIComponent(filter_price);
	}

	var filter_quantity = $('input[name=\'filter_quantity\']').val();

	if (filter_quantity) {
		url += '&filter_quantity=' + encodeURIComponent(filter_quantity);
	}

	var filter_status = $('select[name=\'filter_status\']').val();

	if (filter_status != '*') {
		url += '&filter_status=' + encodeURIComponent(filter_status);
	}

  var filter_image = $('select[name=\'filter_image\']').val();

  if (filter_image != '*') {
    url += '&filter_image=' + encodeURIComponent(filter_image);
  }

	location = url;
});
//--></script>
  <script type="text/javascript"><!--
$('input[name=\'filter_name\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: 'index.php?route=catalog/product/autocomplete&token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&filter_name=' +  encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['name'],
						value: item['product_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'filter_name\']').val(item['label']);
	}
});

$('input[name=\'filter_model\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: 'index.php?route=catalog/product/autocomplete&token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&filter_model=' +  encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['model'],
						value: item['product_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'filter_model\']').val(item['label']);
	}
});
//--></script></div>
<footer id="footer"><a href="">Shop App</a> &copy; 2017-2018 All Rights Reserved.</footer></div>
</body>
</html>
