<!DOCTYPE html>
<html>
<head>
	<title>Demo iuumport database</title>
</head>
<body>
	<form action="<?php echo site_url('uploadExcel') ?>" method="POST" enctype="multipart/form-data">
 
  <input type="file"  name="file" >
  
 <input type= "submit" value ="Upload" >
  
</form>
</body>
</html>