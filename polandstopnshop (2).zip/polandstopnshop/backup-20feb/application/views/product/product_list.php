<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar.php'); ?>

<div id="content">

                               <?php if($this->session->flashdata('message')): ?>
                                
                                   
                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"> 
                                       <?php echo $this->session->flashdata('message');?></a>
                                    </div>  
                              <?php endif;?> 
   
     

                             <?php if($this->session->flashdata('success')): ?>
                                
                                   
                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('success');?></a>
                                    </div>                                   
                                  
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('error')):?>
                                  
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('error');?></a>
                                        </div>
                                       
                                    
                                <?php endif;?>



                              <?php if($this->session->flashdata('w_success')): ?>
                                <ul class="woocommerce-message">
                                  <li>

                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_success');?></a>
                                    </div>
                                   
                                                                        
                                  </li>
                                </ul>
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('w_error')):?>
                                    <ul class="woocommerce-error">
                                      <li>
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_error');?></a>
                                       </div>
                                        
                                      </li>
                                    </ul>
                              <?php endif;?>
  <div class="page-header">
      <div class="container-fluid">
      
      <h1>Products</h1>
              
    </div>
     <div class="container-fluid">
      <div class="pull-right">

     
      <a href="<?php echo site_url('products/add_products_view'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-primary"><i class="fa fa-plus"></i> Add Products</a>

      <a href="<?php echo site_url('products/import_view'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-primary"><i class="fa fa-plus"></i> Add CSV</a>
        
        
      </div>
      
              <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="">Products</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i> Product List</h3>
       
      </div>



      <div class="panel-body">


        
           <div class="row">
            <div class="col-sm-12" style="margin-right: 10px;margin-top: -5px" >
             
               <form class="navbar-form navbar-right" action="<?php echo site_url('search_item/search_products') ?>" method="post" role="search">
                    <div class="form-group">
                      <input class="form-control" name="search" id="search" placeholder="Search" type="text">
                     
                    </div>
                    <button type="submit" class="btn btn-default">Submit</button>
               </form>       
            </div>
         
          </div> 
        


        <div>
       
          
        </div>
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  
                  <!-- <td style="width: 1px;" class="text-center"><input type="checkbox" onclick="$('input[name*=\'selected\']').prop('checked', this.checked);" /></td> -->


                  <td class="text-center">Image</td>
                  <td class="text-left"> 
                      Product Name
                  </td>
                  <td class="text-left"> 
                      Category
                  </td>
                  <td class="text-left">
                      Description
                  </td>
                  <td class="text-left"> 
                      Price
                  </td>
                 
                  <td class="text-left"> 
                      Product Number
                  </td>

                  <td class="text-left"> 
                      Detail
                  </td>
                 
                  <td class="text-left">Action</td>
                </tr>
              </thead>
              <tbody>
                                              
              <?php  
         foreach ($product->result() as $products)  
         { 
  ?>
                <tr>
                    <!-- <td class="text-center">     
                       <input type="checkbox" name="selected[]" value="42" />
                    </td> -->
                    <td class="text-center">
                       <img src="<?php echo base_url();?>upload/<?php echo $products->image;?>" alt="" class="img-thumbnail" style="width:80px; height:80px"/>
                    </td>
                    <td class="text-left"><?php echo $products->name;?></td>
                    <td class="text-left"><?php echo $products->categoryName;?></td>
                    <td class="text-left"><?php echo $products->description;?></td>
                    <td class="text-left">
                          <!-- <span style="text-decoration: line-through;">100.0000</span> -->

                          <br/>

                          <div class="text-danger"><?php echo $products->price;?></div>

                    </td>
                    <td><?php echo $products->ProductNumber;?></td>
                    <td class="text-left"> <a href=""><?php echo anchor("products/product_detail/$products->id",'view more',['class'=>'btn btn-info'])?></a></td>

                    <td>

                    <?php echo anchor("products/edit_form_view/$products->id",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary'])?>

                    <?php echo anchor("products/delete_product/$products->id",'<i class="fa fa-close"></i>',['class'=>'btn btn-danger', 'onClick'=>"return doconfirm();"])?>

                    
                    </td>
                </tr>
              <?php } ?>
                       
              </tbody>
            </table>
	          <?php echo $this->pagination->create_links(); ?>	
          </div>
        </form>

      </div>
    </div>
  </div>
  <script>
function doconfirm() {
    return confirm("Are You Sure Delete This Product ?")
}
</script>
 
 <!--  <script type="text/javascript"><!--
$('input[name=\'filter_name\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: 'index.php?route=catalog/product/autocomplete&token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&filter_name=' +  encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['name'],
						value: item['product_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'filter_name\']').val(item['label']);
	}
});

$('input[name=\'filter_model\']').autocomplete({
	'source': function(request, response) {
		$.ajax({
			url: 'index.php?route=catalog/product/autocomplete&token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&filter_model=' +  encodeURIComponent(request),
			dataType: 'json',
			success: function(json) {
				response($.map(json, function(item) {
					return {
						label: item['model'],
						value: item['product_id']
					}
				}));
			}
		});
	},
	'select': function(item) {
		$('input[name=\'filter_model\']').val(item['label']);
	}
});
//</script> --></div>
<footer id="footer"><a href="">Shop App</a> &copy; 2017-2018 All Rights Reserved.</footer></div>
</body>
</html>
