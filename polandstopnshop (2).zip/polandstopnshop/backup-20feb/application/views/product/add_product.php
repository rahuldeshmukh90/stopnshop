<?php $this->load->view('template/head'); ?>

<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header.php'); ?>
<?php $this->load->view('template/left_sidebar.php'); ?>
<div id="content">
  <div class="page-header">
      <div class="container-fluid">
    
      <h1>Products</h1>
      
    </div>

    <div class="container-fluid">
        <div class="pull-right">
        <!-- <button type="submit" form="form-product" data-toggle="tooltip" title="Save" class="btn btn-primary"><i class="fa fa-save"></i></button> -->
       </div>
      <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('products/all_products'); ?>">Products</a></li>
                <li><a href="">Add Product</a></li>
              </ul>
    </div>
  
  </div>




  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Add Product</h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo site_url('products/add_products'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Product Details</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">
                                <div class="" id="">

                
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Product Name</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="name"  placeholder="Product Name" class="form-control" />
                    </div>

                  </div>

                   <div class="form-group required">

                    <label class="col-sm-2 control-label" for="input-category">Category</label>
                    
                    <div class="col-sm-10">

                       <select name="categoryId" class="form-control" required="">
                        <option value=""> Please Select a Category....</option>
                        <?php
                          $count = 1 ;    
                          foreach ($category->result() as $categories)  
                              { 
                            ?>
                        <option name="categoryId" value="<?php echo $categories->id;?>"><h3><?php echo $categories->name;?></h3></option>

                        <?php } ?>
                    </select>
                      
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-image">Product image</label>
                    
                    <div class="col-sm-10">
                      <input type="file" name="image" />
                    </div>

                  </div>

                    <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-meta-title1">Products Price</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="price" value="" placeholder="Products Price" class="form-control" />
                    </div>

                  </div>


                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-description1">Description</label>
                    
                    <div class="col-sm-10">
                      <textarea name="description" placeholder="Description" class="form-control summernote"></textarea>
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-product-number">Products Number</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="productNumber" placeholder="Products Number" class="form-control" />
                    </div>

                  </div>

                  <!-- <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-meta-description1">Meta Tag Description</label>
                    <div class="col-sm-10">
                      <textarea name="description1" rows="5" placeholder="Meta Tag Description" class="form-control"></textarea>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-meta-keyword1">Meta Tag Keywords</label>
                    
                    <div class="col-sm-10">
                      <textarea name="keyword" rows="5" placeholder="Meta Tag Keywords" class="form-control"></textarea>
                    </div>
                  </div> -->

                  <div class="form-group">
                  
                    
                    <div class="col-sm-10">
                       

                      <input type="submit" value="Add product" class="btn btn-primary">

                      <a class="btn btn-default" href="<?php echo site_url('products/all_products'); ?>">Cancel</a>
                    </div>
                  </div>
                 

              
                </div>
                               
              </div>
            </div>


        
          </div>
        </form>
      </div>
    </div>
  </div>
<script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    name: "required",
                    categoryId: "required",
                    //image: "required",
                    
                    price:{
                              required: true,
                              number: true
                            },
                    description: "required",        
                    productNumber: "required",        
                   
                   
                },
                messages: {
                    name: "<P class='text-danger'>Please enter your name</p>",
                    categoryId: "<P class='text-danger'>please choose category</p>",
                    //image: "<P class='text-danger'>image is required</p>",
                    
                    price:{
                              required:  "<P class='text-danger'>price is required..</p>",
                             
                              number:    "<P class='text-danger'>Please Enter Valide Number.</p>"
                            },
                    
                    description: "<P class='text-danger'>description field is required.</p>",

                    productNumber: "<P class='text-danger'>product number is required.</p>",

                   
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>



</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
