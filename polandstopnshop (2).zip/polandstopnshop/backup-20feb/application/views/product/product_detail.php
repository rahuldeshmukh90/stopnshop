<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->load->view('template/header'); ?>
<?php  $this->load->view('template/left_sidebar'); ?>

<div id="content">

  <div class="page-header">
        
     <div class="container-fluid">
      <br />
      
      <h1>Products Detail</h1>
      
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="">Product Detail</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i> Product Detail</h3>
      </div>
      <div class="panel-body">
        <div class="col-sm-4">
           <img width="100%" class="img-responsive" src="<?php echo base_url();?>upload/<?php echo $product->image;?>"  alt="image" />
        </div> 
        <div class="col-sm-8">
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <div class="col-sm-12"><h1 class="text-center"><?php echo $product->name;?></h1></div> 

            <table class="table">
             
              <tbody>
                 <tr>
                    <td class="text-left"><b>Name</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->name;?></td>    
                </tr>
             
               
                <tr>
                    <td class="text-left" colspan="1"><b>Price</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->price;?></td>    
                </tr>
                <!--<tr>
                    <td class="text-left" colspan="1"><b>Quantity</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->qnty;?> , </td>    
                </tr>-->
                 <tr>
                    <td class="text-left" colspan="1"><b>Description</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->description;?></td>    
                </tr>

                <tr>
                    <td class="text-left" colspan="1"><b>Product Number</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->ProductNumber;?></td>    
                </tr>
                
              </tbody>
            </table>
          </div>
        </form>
       </div> 
      </div>
    </div>
  </div>
 </div>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
