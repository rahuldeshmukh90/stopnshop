<?php $this->load->view('template/head'); ?>
<body>

<div id="container">
  <?php $this->load->view('template/header.php'); ?>
<?php $this->load->view('template/left_sidebar.php'); ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
     
      <h1> IMPORT FILE </h1>
     
    </div>
  </div>
  <div class="container-fluid">
               <ul class="breadcrumb">
                 <li><a href="">Home</a></li>
                 <li><a href="">Import file</a></li>
              </ul>
    <div class="panel panel-default">
              
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-exchange"></i>Import file </h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo base_url(); ?>index.php/uploadcsv/import" method="post" enctype="multipart/form-data"  class="form-horizontal">
          <div class="form-group">

            <label class="col-sm-2 control-label" for="input-import"> IMPORT FILE </label>
            <div class="col-sm-8">
              <input type="file" name="file" id="file" accept=".csv">
              
            </div>
            <div class="col-sm-12" style="margin-bottom: 20px"></div>
            <div class="col-sm-10">
            <p class="text-danger" style="margin-left: 46px;padding:20px"><b> Note : </b> You can upload file only CSV format</p>
            </div>
            <div class="col-sm-2">.</div>
             
            <div class="col-sm-10" class="pull-right">
              <input type="submit" style="margin-left: 63px" id="submit" name="import" value="Upload file" class="btn btn-info"/>
            </div>
          </div>
        </form>
        <div>                 

</div>
      </div> 
      <div>                 

  <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    file: "required",
                   
                },
                messages: {
                    file: "<P class='text-danger'>Please select any csv file.</p>",
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>

</div>
    </div>
  </div>
</div>
<footer id="footer"><a href="">ShopApp</a> &copy; 2017-2018 All Rights Reserved.</footer></div>
</body></html>
