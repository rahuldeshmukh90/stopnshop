<header id="header" class="navbar navbar-static-top">
  <div class="navbar-header">
        <a type="button" id="button-menu" class="pull-left"><i class="fa fa-indent fa-lg"></i></a>
        <a  class="navbar-brand"><img src="<?php echo base_url(); ?>assets/images/adminlogo.png" alt="shopApp" title="shopApp" /></a></div>



    <ul class="nav pull-right">
    
    <?php  $id = $this->session->userdata('id'); ?>
    <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user fw fa-lg"></i></a>
    <?php $logged_in_user = $this->login_model->is_logged_in();

       $admin_id = $this->session->userdata('id');
     ?>

      <ul class="dropdown-menu dropdown-menu-right">
        
        <li><a href="<?php echo site_url('admin_login/profile_view'); ?>" target="_blank"><b><i class="fa fa-user fw fa-lg"></i> Profile </b></a></li>

        <li>
   <?php echo anchor("admin_login/update_admin_view/$admin_id",'<b><i class="fa fa-pencil"></i> Edit Profile </b>')?>

        </li>

        <li><a href="<?php echo site_url('admin_login/logout'); ?>" ><b><i class="fa fa-sign-out fa-lg"></i> Log-Out</b></a></li>

      </ul>
    </li>
    <li><a href="<?php echo site_url('admin_login/logout'); ?>"><span class="hidden-xs hidden-sm hidden-md">Logout</span> <i class="fa fa-sign-out fa-lg"></i></a></li>
  </ul>

  
  </header>
  