<nav id="column-left">
  <div id="profile">
    <a href="<?php echo site_url('admin_login/profile_view'); ?>">
    <div>
            <i class="fa fa-user"></i>
    </div>
    <div>
      <h4>Admin</h4>
      <small>Administrator</small></div>
     </a> 
  </div>
  <ul id="menu">
        <li id="menu-dashboard">
            <a href="<?php echo site_url('admin_login/dashboard'); ?>"><i class="fa fa-dashboard fw"></i> <span>Dashboard</span></a>
                </li>
        <li id="menu-extension">
            <a class="parent"><i class="fa fa-car fw"></i> <span>Products</span></a>
                  <ul>
               
                            <li>
                    <a href="<?php echo site_url('products/all_products'); ?>">Product</a>
                            </li>
                
              </ul>
        </li>   

        <li id="menu-extension">
            <a class="parent"><i class="fa fa-gift"></i> <span>Combo Deal</span></a>
                  <ul>
                      <li>
                          <a href="<?php echo site_url('combo/combolist'); ?>">deal</a>
                      </li>
                
              </ul>
        </li>

        <li id="menu-extension">
            <a class="parent"><i class="fa fa-bar-chart fw"></i> <span>Categories</span></a>
                  <ul>
                      <li>
                          <a href="<?php echo site_url('categories/category_list'); ?>">Category</a>
                      </li>
                
              </ul>
        </li>  
        <li id="menu-customer" class="open">
            <a class="parent"><i class="fa fa-user fw"></i> <span>Customers</span></a>
                  <ul class="collapse in" aria-expanded="true" style="">
                <li>
                    <a href="<?php echo site_url('customers/customers_list'); ?>">Customers List</a>
                            </li>
               <!--  <li>
                    <a href="http://localhost/open/admin/index.php?route=customer/customer_group&amp;token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq">Customer Groups</a>
                            </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=customer/custom_field&amp;token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq">Custom Fields</a>
                            </li> -->
              </ul>
          </li>

          </li>   
          <li id="menu-extension">
            <a class="parent"><i class="fa fa-shopping-cart fw"></i> <span>Store</span></a>
                  <ul>
                      <li>
                          <a href="<?php echo site_url('customers/store'); ?>">Store</a>
                      </li>
                
              </ul>
        </li>

         <li id="menu-extension">
            <a class="parent"><i class="fa fa-fire fw"></i> <span>Gas</span></a>
                  <ul>
                      <li>
                          <a href="<?php echo site_url('gas/gas_detail'); ?>">gas</a>
                      </li>
                
              </ul>
        </li>

        <li id="menu-extension">
            <a class="parent"><i class="fa fa-user fw"></i> <span>Request</span></a>
                  <ul>
                      <li>
                          <a href="<?php echo site_url('request/request_list'); ?>">request</a>
                      </li>
                
              </ul>
        </li>

        <li id="menu-extension">
            <a class="parent"><i class="fa fa-user fw"></i> <span>Order</span></a>
                  <ul>
                      <li>
                          <a href="<?php echo site_url('order/allorderlist'); ?>">Order Report</a>
                      </li>
                
              </ul>
        </li>

       <li id="menu-catalog">
            <a class="parent"><i class="fa fa-tags fw"></i> <span>Import File</span></a>
                  <ul>
                    <li>
                    <a href="<?php echo site_url('products/import_view'); ?>" class="parent">Import-File</a>
                          
                    </li>
                  </ul>
        </li>            
                    <!--
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/product&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Products</a>
                            </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/recurring&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Recurring Profiles</a>
                            </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/filter&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Filters</a>
                            </li>
                <li>
                    <a class="parent">Attributes</a>
                              <ul>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=catalog/attribute&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Attributes</a>
                                        </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=catalog/attribute_group&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Attribute Groups</a>
                                        </li>
                      </ul>
                  </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/option&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Options</a>
                            </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/manufacturer&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Manufacturers</a>
                            </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/download&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Downloads</a>
                            </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/review&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Reviews</a>
                            </li>
                <li>
                    <a href="http://localhost/open/admin/index.php?route=catalog/information&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Information</a>
                            </li>
              </ul>
          </li> -->
        
        
        <!-- <li id="menu-system">
            <a class="parent"><i class="fa fa-cog fw"></i> <span>System</span></a>
                  <ul>
                <li>
                    <a href="#">Settings</a>
                            </li>
                <li>
                    <a class="parent">Users</a>
                              <ul>
                        <li>
                            <a href="#">Users</a>
                                        </li>
                        <li>
                            <a href="#">User Groups</a>
                                        </li>
                        <li>
                            <a href="#">API</a>
                                        </li>
                      </ul>
                  </li>
                <li>
                    <a class="parent">Localisation</a>
                              <ul>
                        <li>
                            <a href="#">Store Location</a>
                                        </li>
                        <li>
                            <a href="#">Languages</a>
                                        </li>
                        <li>
                            <a href="#">Currencies</a>
                                        </li>
                        <li>
                            <a href="#">Stock Statuses</a>
                                        </li>
                        <li>
                            <a href="#">Order Statuses</a>
                                        </li>
                        <li>
                            <a class="parent">Returns</a>
                                          <ul>
                                <li><a href="#">Return Statuses</a></li>
                                <li><a href="#">Return Actions</a></li>
                                <li><a href="#">Return Reasons</a></li>
                              </ul>
                          </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=localisation/country&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Countries</a>
                                        </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=localisation/zone&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Zones</a>
                                        </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=localisation/geo_zone&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Geo Zones</a>
                                        </li>
                        <li>
                            <a class="parent">Taxes</a>
                                          <ul>
                                <li><a href="http://localhost/open/admin/index.php?route=localisation/tax_class&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Tax Classes</a></li>
                                <li><a href="http://localhost/open/admin/index.php?route=localisation/tax_rate&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Tax Rates</a></li>
                              </ul>
                          </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=localisation/length_class&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Length Classes</a>
                                        </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=localisation/weight_class&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Weight Classes</a>
                                        </li>
                      </ul>
                  </li>
                <li>
                    <a class="parent">Tools</a>
                              <ul>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=tool/upload&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Uploads</a>
                                        </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=tool/backup&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Backup / Restore</a>
                                        </li>
                        <li>
                            <a href="http://localhost/open/admin/index.php?route=tool/log&amp;token=o237ou9pRdZbYjwxllOxOjv7HDf7482k">Error Logs</a>
                                        </li>
                      </ul>
                  </li>
              </ul>
          </li> -->

      </ul>
  <!-- <div id="stats">
    <ul>
      <li>
        <div>Orders Completed <span class="pull-right">0%</span></div>
        <div class="progress">
          <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"> <span class="sr-only">0%</span></div>
        </div>
      </li>
      <li>
        <div>Orders Processing <span class="pull-right">100%</span></div>
        <div class="progress">
          <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"> <span class="sr-only">100%</span></div>
        </div>
      </li>
      <li>
        <div>Other Statuses <span class="pull-right">0%</span></div>
        <div class="progress">
          <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"> <span class="sr-only">0%</span></div>
        </div>
      </li>
    </ul>
  </div> -->
</nav>