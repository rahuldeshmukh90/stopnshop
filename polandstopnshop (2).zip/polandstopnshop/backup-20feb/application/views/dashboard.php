
<?php include('template/head.php'); ?>

<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php include('template/header.php'); ?>
<?php include('template/left_sidebar.php') ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <h1>Dashboard</h1>
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb">
                <li><a href="">Home</a></li>
                <li><a href="">Dashboard</a></li>
              </ul>
    </div>
  </div>
  <div class="container-fluid">

        <!-- <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> Warning: Install folder still exists and should be deleted for security reasons!      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
           -->  <div class="row">
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="tile">
                    <div class="tile-heading">Total Customers <span class="pull-right">
                          0%</span></div>
                    <div class="tile-body"><i class="fa fa-user"></i>
                      <h2 class="pull-right"><?php echo $this->customer_model->total_customers(); ?></h2>
                    </div>
                      <div class="tile-footer"><a href="#">View more...</a></div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="tile">
                    <div class="tile-heading">Total Products <span class="pull-right">
                      0%</span>
                    </div>
                    <div class="tile-body"><i class="fa fa-shopping-cart"></i>
                      <h2 class="pull-right"><?php echo $this->product_model->total_products(); ?></h2>
                    </div>
                    <div class="tile-footer"><a href="#">View more...</a></div>
                  </div>
                  </div>
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="tile">
                    <div class="tile-heading">Total Request <span class="pull-right">
                          0% </span></div>
                    <div class="tile-body"><i class="fa fa-user-plus"></i>
                      <h2 class="pull-right"><?php echo $this->request_model->total_request(); ?></h2>
                    </div>
                    <div class="tile-footer"><a href="#">View more...</a></div>
                  </div>
                  </div>
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="tile">
                    <div class="tile-heading">total favorite item</div>
                    <div class="tile-body"><i class="fa fa-plus"></i>
                      <h2 class="pull-right"><?php echo $this->request_model->total_favorite(); ?></h2>
                    </div>
                    <div class="tile-footer"><a href="#">View more...</a></div>
              </div>
              </div>
          </div>
       
        <div class="row">
          <div class="col-lg-6 col-md-12 col-sm-12"><div class="panel panel-default">
            <div class="panel-heading">
              <h3 class="panel-title"><i class="fa fa-calendar"></i>Latest Customer</h3>
            </div>
            <div class="table-responsive">

   
    <table class="table">
      <thead>
        <tr>
          <td class="text-right">ID</td>
          <td>Customer Name</td>
          <td>Mobile Number</td>
          <td>EmailID</td>
          <td class="text-right">Date</td>
         <!--  <td class="text-right">Action</td> -->
        </tr>
      </thead>
      <tbody>
        <?php foreach ($latestcustomer as $customer) { ?>   
        <tr>
          <td class="text-right"><?php echo $customer['id']; ?></td>
          <td><?php echo $customer['name']." ".$customer['lastName']; ?></td>
          <td><?php echo $customer['contact']; ?></td>
          <td><?php echo $customer['email']; ?></td>
          <td class="text-right"><?php echo $customer['addedDate']; ?></td>
          <!-- <td class="text-right"><a href="#" data-toggle="tooltip" title="View" class="btn btn-info"><i class="fa fa-eye"></i></a></td> -->
        </tr>
       <?php } ?>   
      </tbody>
    </table>
  </div>
</div></div>
          <div class="col-lg-6 col-md-12 col-sm-12"><div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title"><i class="fa fa-shopping-cart"></i> Latest Orders</h3>
  </div>
  <div class="table-responsive">
    <table class="table">
      <thead>
        <tr>
          <td class="text-right">ID</td>
          <td>Customer</td>
          <td>Status</td>
          <td>Date Added</td>
          <td class="text-right">Total</td>
          <td class="text-right">Action</td>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($latestorder as $order) { ?>   
      
        <tr>
          <td class="text-right"><?php echo $order['id']; ?></td>
          <td><?php echo $order['name']." ".$order['lastName']; ?></td>
          <td>Pending</td>
          <td><?php echo $order['addedDate']; ?></td>
          <td class="text-right"><?php echo $order['amount']; ?></td>
          <td class="text-right"><!-- <a href="<?php echo base_url(''); ?>" data-toggle="tooltip" title="View" class="btn btn-info"><i class="fa fa-eye"></i></a> -->


          <a href=""><?php echo anchor("order/order_detail/".$order['id'],'view more',['class'=>'btn btn-info'])?></a>
          </td>
        </tr>

        <?php } ?>
                
      </tbody>
    </table>
  </div>
</div>
</div>
          </div>
      </div>
</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
