<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">

  <div class="page-header">
         <?php if($this->session->flashdata('success')): ?>
                                
                                   
                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('success');?></a>
                                    </div>                                   
                                  
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('error')):?>
                                  
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('error');?></a>
                                        </div>
                                    
                                <?php endif;?>



                              <?php if($this->session->flashdata('w_success')): ?>
                                <ul class="woocommerce-message">
                                  <li>

                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_success');?></a>
                                    </div>
                                   
                                                                        
                                  </li>
                                </ul>
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('w_error')):?>
                                    <ul class="woocommerce-error">
                                      <li>
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_error');?></a>
                                       </div>
                                        
                                      </li>
                                    </ul>
                                    
                              <?php endif;?>
     <div class="container-fluid">
      <br />
      
      <h1>Gas Detail</h1>
      
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="">Gas Detail</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i> Gas Detail</h3>
      </div>
      <div class="panel-body">
       
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">


            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  
                  <td class="text-left"> 
                      Name
                  </td>
                  <td class="text-left">
                      Price
                  </td>
                  <td class="text-left">
                      Date
                  </td>
                 
                  <td class="text-right">Action</td>
                </tr>
              </thead>
              <tbody>

                
                       <?php  
         foreach ($gas->result() as $get_gas)  
         { 
  ?>
      
                <tr>
                    <td class="text-left">  
			                   <?php echo $get_gas->name;?>
							      </td>
                    <td class="text-left"><?php echo $get_gas->price;?></td>
                        
                    <td class="text-left"><?php echo $get_gas->addedDate;?></td>
                    
                    <td class="text-right">

                      <?php echo anchor("gas/update_gasview/$get_gas->id",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary'])?>

                   </td>
                </tr>

              
<?php } ?>

              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
 </div>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
