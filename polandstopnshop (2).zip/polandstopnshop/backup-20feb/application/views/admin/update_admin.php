<?php $this->load->view('template/head'); ?>

<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">

      <h1>Profile</h1>
     
    </div>
    <div class="container-fluid">
      <div class="pull-right">
       <!--  <button type="submit" form="" data-toggle="tooltip" title="Save" class="btn btn-primary"><i class="fa fa-save"></i></button> -->
        <a href="" data-toggle="tooltip" title="Cancel" class="btn btn-default"><i class="fa fa-reply"></i></a></div>

      <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('customers/customers_list'); ?>">Customer list</a></li>
                <li><a href="">Edit Admin Profile</a></li>
              </ul>
    </div>
    
  </div>




  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Edit Admin Profile</h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo site_url('admin_login/update_admin'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Admin</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">
                                <div class="" id="">

                
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Admin Name</label>
                    
                    <div class="col-sm-10">
                      <input type="hidden" name="id"  value="<?php echo $admin->id;?>" class="form-control" />

                      <input type="text" name="admin_name"  value="<?php echo $admin->admin_name;?>" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="email">Admin Email</label>
                    
                    <div class="col-sm-10">

                      <input type="text" name="admin_email" value="<?php echo $admin->admin_email;?>"  class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">

                    <label class="col-sm-2 control-label" for="Mobile Number">Mobile Number</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="contact_no"  value="<?php echo $admin->contact_no;?>"  class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-password"> New Password</label>
                    
                    <div class="col-sm-10">
                      <input type="password" id="password" name="password" placeholder="******"  class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-cPassword"> Confirm Password</label>
                    
                    <div class="col-sm-10">
                      <input type="password" id="cpassword" name="cpassword" placeholder="******" class="form-control" />
                    </div>

                  </div>
               
                  <div class="form-group">
                  
                    
                    <div class="col-sm-10">

                      <input type="submit" value="Update Profile" class="btn btn-primary">
                      <a class="btn btn-default" href="<?php echo site_url('admin_login/profile_view'); ?>">Cancel</a>
                    </div>
                  </div>
                 

              
                </div>
                               
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
  
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                          password:{
                              
                              minlength: 4
                            },
                          cpassword:{
                              
                              equalTo: '#password'
                            }
                        },
                messages: {
                       password:{
                              
                              minlength: "The length of password must be greater than 4"
                            },
                       cpassword:{
                              
                              equalTo: "Password and confirm password do not match."
                            }
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script> 
</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
  