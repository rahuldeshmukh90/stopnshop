<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">

<style>

   #panel_body1{
   background-color: whitesmoke;
  }
 
</style>
    <div class="page-header">

           <div class="container-fluid">

             <h1>Profile</h1>
        </div>

           <div class="container-fluid">
           
            <ul class="breadcrumb">
                                 <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                                <li><a href="#">Profile</a></li>
                            </ul>
                            <br />
                          
        </div>
        
    </div>
    <div class="container-fluid">
                               <!--  <div class="alert alert-info"><i class="fa fa-info-circle"></i> Thumbnail Image, Homethumb Image, Featured column(s) already exist in database.            <button type="button" class="close" data-dismiss="alert">&times;</button> -->
        </div>
                <div class="panel panel-default">
           
            <div class="panel-body">
                <div class="table-responsive">
                  <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h3 class="panel-title">Admin Profile</h3>
                        </div>
                        <div class="panel-body" id="panel_body1">
                            <div class="col-sm-2">
                                <img src="<?php echo base_url();?>upload/59ad2d7507bf8.png" class="img-responsive img-thumbnail" title="profile image">
                            </div>
                            <div class="col-sm-6">
                             <table class="table table-striped table-hover ">
 
								  <tbody>
                    <?php $logged_in_user = $this->login_model->get_logged_in_user_info();?>
								    <tr>
								      
								      <td> NAME </td>
								      <td>:</td>
								      <td><?php echo $logged_in_user->admin_name; ?></td>
								    </tr>
								    <tr>
								      
								    </tr>
								    <tr>
								      
								      <td> EMAIL </td>
								      <td>:</td>
								      <td><?php echo $logged_in_user->admin_email; ?></td>
								    </tr>
								    <tr>
								      
								    </tr>
								    <tr>
								      
								      <td>MOBILE NUMBER</td>
								      <td>:</td>
								      <td><?php echo $logged_in_user->contact_no; ?></td>
								    </tr>
								    <tr>
								      
								    </tr>
								    
								   
								  </tbody>
								</table> 

								<?php echo anchor("admin_login/update_admin_view/$logged_in_user->id",'<i class="fa fa-pencil"> </i> Edit Profile ',['class'=>'btn btn-info'])?>

								
                            </div>

                        </div>
                  </div>

     
                </div>
            </div>
        </div>
    </div>
 </div>
<footer id="footer"><a href="">Shop App</a> &copy; 2017-2018 All Rights Reserved.</footer></div>
</body></html>
