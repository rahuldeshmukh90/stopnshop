<?php include('template/head.php'); ?>

<body>
<div id="container">
<header id="header" class="navbar navbar-static-top">
  <div class="navbar-header">
        <a href="" class="navbar-brand"><img src="<?php echo base_url(); ?>assets/images/adminlogo.png" alt="shopApp" title="shopApp" /></a></div>
  </header>
<div id="content">
  <div class="container-fluid"><br />
    <br />
    <div class="row">
      <div class="col-sm-offset-4 col-sm-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h1 class="panel-title"><i class="fa fa-repeat"></i> Forgot Your Password?</h1>
          </div>
          <div class="panel-body">
                        <form action="http://localhost/open/admin/index.php?route=common/forgotten" method="post" enctype="multipart/form-data">
              <div class="form-group">
                <label for="input-email">E-Mail Address</label>
                <div class="input-group"><span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                  <input type="text" name="email" value="" placeholder="E-Mail Address" id="input-email" class="form-control" />
                </div>
              </div>
              <div class="text-right">
                <button type="submit" class="btn btn-primary"><i class="fa fa-check"></i> Reset</button>
                <a href="<?php echo site_url('admin_login/index'); ?>" data-toggle="tooltip" title="Cancel" class="btn btn-default"><i class="fa fa-reply"></i></a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<footer id="footer"><a href="http://www.opencart.com">ShopApp</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
