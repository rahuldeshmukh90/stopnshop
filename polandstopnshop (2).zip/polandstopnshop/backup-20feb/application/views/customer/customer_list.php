<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">
  <div class="page-header">

       <?php if($this->session->flashdata('success')): ?>
                                
                                   
                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('success');?></a>
                                    </div>                                   
                                  
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('error')):?>
                                  
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('error');?></a>
                                        </div>
                                    
                                <?php endif;?>



                              <?php if($this->session->flashdata('w_success')): ?>
                                <ul class="woocommerce-message">
                                  <li>

                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_success');?></a>
                                    </div>
                                   
                                                                        
                                  </li>
                                </ul>
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('w_error')):?>
                                    <ul class="woocommerce-error">
                                      <li>
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_error');?></a>
                                       </div>
                                        
                                      </li>
                                    </ul>
                              <?php endif;?>
                              
       <div class="container-fluid">
      <h1>Customer's</h1>
    </div>
      <div class="container-fluid">
      <div class="pull-right">


      <a href="<?php echo site_url('customers/customer_view'); ?>" data-toggle="tooltip" title="Add New" class="btn btn-primary"><i class="fa fa-plus"></i> Add customer</a>
        
        
      </div>
    
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="">Customers</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i> Customer List</h3>
      </div>
      <div class="panel-body">
         
         <div class="row">
            <div class="col-sm-12" style="margin-right: 10px;margin-top: -5px" >
             
               <form class="navbar-form navbar-right" action="<?php echo site_url('search_item/search_customer') ?>" method="post" role="search">
                    <div class="form-group">
                      <input class="form-control" name="search" id="search" placeholder="Search" type="text">
                      <input type="hidden" value="search">
                    </div>
                    <button type="submit" class="btn btn-default">Submit</button>
               </form>       
            </div>
         
          </div>



        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  
                  <td class="text-left"> 
                      Customer Name
                  </td>
                  <td class="text-left">
                      Email
                  </td>
                  <td class="text-left">
                      Mobile Number
                  </td>
                 
                  <td class="text-left">   
                      Date of Birth
                    </td>
                  <td class="text-left">   
                      Status
                  </td>  
                  <td class="text-right">Action</td>
                </tr>
              </thead>
              <tbody>

                 <?php  
         foreach ($product->result() as $products)  
         { 
  ?>
                <tr>
                    
                    <td class="text-left"><?php echo $products->name;?> <?php echo $products->lastName;?></td>
                    <!-- <td><img src="<?php echo base_url();?>assets/upload/<?php echo $products->pro_image;?>"</td> -->
                    <td class="text-left"><?php echo $products->email;?></td>
                    <td class="text-left">
                          <!-- <span style="text-decoration: line-through;">100.0000</span> -->

                          <br/>

                          <div class=""><?php echo $products->contact;?></div>

                    </td>
                   
                    <td class="text-left"><?php echo $products->dob ; ?></td>
                    <td class="text-left"><?php echo $products->status ; ?></td>
                    <td class="text-right">
                    <?php echo anchor("customers/updatecustomer__view/$products->id",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary'])?>

                    <?php echo anchor("customers/delete_customer/$products->id",'<i class="fa fa-close"></i>',['class'=>'btn btn-danger' , 'onClick'=>"return doconfirm();"])?>
                </tr>

              <?php } ?>


              </tbody>
            </table>
            <?php echo $this->pagination->create_links(); ?> 
          </div>
        </form>
      <!--   <div class="row">
          <div class="col-sm-6 text-left"><ul class="pagination"><li class="active"><span>1</span></li><li><a href="http://localhost/open/admin/index.php?route=catalog/product&amp;token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&amp;page=2">2</a></li><li><a href="http://localhost/open/admin/index.php?route=catalog/product&amp;token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&amp;page=3">3</a></li><li><a href="http://localhost/open/admin/index.php?route=catalog/product&amp;token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&amp;page=2">&gt;</a></li><li><a href="http://localhost/open/admin/index.php?route=catalog/product&amp;token=I1M4DFd4NIbIB5Wg9mU40UJd0df6FJzq&amp;page=3">&gt;|</a></li></ul></div>
          <div class="col-sm-6 text-right">Showing 1 to 20 of 55 (3 Pages)</div>
        </div> -->
      </div>
    </div>
  </div>
 </div>
 <script>
function doconfirm() {
    return confirm("Are You Sure Delete This Customer ?")
}
</script>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
