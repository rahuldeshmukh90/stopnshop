<?php $this->load->view('template/head'); ?>

<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">
  <div class="page-header">
     <div class="container-fluid">
      <h1>Customer</h1>
    </div>
     <div class="container-fluid">
      <div class="pull-right">
        <!-- <button type="submit" form="" data-toggle="tooltip" title="Save" class="btn btn-primary"><i class="fa fa-save"></i></button> -->
      <!--   <a href="" data-toggle="tooltip" title="Cancel" class="btn btn-default"><i class="fa fa-reply"></i></a> --></div>
     
      <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('customers/customers_list'); ?>">Customer </a></li>
                <li><a href="">Add Customer</a></li>
              </ul>
    </div>
    
  </div>





  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Add Customer</h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo site_url('customers/add_customer'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Customer</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">
                                <div class="" id="">

                
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">First Name</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="name"  placeholder="First Name" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Last Name</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="lastName"  placeholder="Last Name" class="form-control" />
                    </div>

                  </div>

                   <div class="form-group required">

                    <label class="col-sm-2 control-label" for="input-description">Mobile Number</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="contact"  placeholder="Mobile Number" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-image">Customer Email</label>
                    
                    <div class="col-sm-10">

                      <input type="text" name="email" placeholder="Email" class="form-control" />
                    </div>

                  </div>

                 
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-password"> password </label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="password" value="" placeholder="Password" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-dob"> Date of Birth </label>
                    
                    <div class="col-sm-10">
                      <input type="date" name="dob" value="" placeholder="Date of Birth" class="form-control" />
                    </div>

                  </div>

                  
                
                  <div class="form-group">
                  
                    
                    <div class="col-sm-10">
                      <input type="submit" value="Add Customer" class="btn btn-primary">                        
<a class="btn btn-default" href="<?php echo site_url('customers/customers_list'); ?>">Cancel</a>
                    </div>
                  </div>
                 

              
                </div>
                               
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
 <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    name: "required",
                    lastName: "required",
                    email:{
                              required: true,
                              email: true
                            },
                    contact:{
                              required: true,
                              minlength: 10,
                              maxlength: 10,
                              digits: true
                            },
                    password: "required",        
                    dob: "required",
                   
                   
                },
                messages: {
                    name: "<P class='text-danger'>Please enter your name</p>",
                    lastName: "<P class='text-danger'>Please enter your last name</p>",
                    email:{
                              required: "<P class='text-danger'>Please fill email address</p>",
                                 email: "<P class='text-danger'>Please provide valid email address</p>"
                            },
                    contact:{
                              required:  "<P class='text-danger'>Please fill contact number.</p>",
                              minlength: "<P class='text-danger'>Phone number must be 10 digit long </p></p></p>",
                              maxlength: "<P class='text-danger'>Phone number must be 10 digit long</p></p>",
                              digits:    "<P class='text-danger'>Enter numeric value.</p>"
                            },
                    
                    password: "<P class='text-danger'>password field is required.</p>",
                    dob: "<P class='text-danger'>Please enter your date of birth</p>",
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>
</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
