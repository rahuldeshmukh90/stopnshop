<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">

  <div class="page-header">
        
     <div class="container-fluid">
      <br />
      
      <h1>Store Detail</h1>
      
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="<?php echo site_url('customers/store'); ?>">store</a></li>
                <li><a href="">store Detail</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i> Store Detail</h3>
      </div>
      <div class="panel-body">
       
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">


            <table class="table" border="1px solid white">
             
              <tbody>
                 <tr>
                    <td class="text-left" colspan="1"><b>Name</b></td>
                    <td class="text-left" colspan="5" ><?php echo $store->name;?></td>    
                </tr>
                <tr>
                    <td class="text-left" colspan="1"><b>Latitude</b></td>
                    <td class="text-left" colspan="5" ><?php echo $store->latitude;?></td>    
                </tr>
                <tr>
                    <td class="text-left" colspan="1"><b>Longitude</b></td>
                    <td class="text-left" colspan="5" ><?php echo $store->longitude;?></td>    
                </tr>
                <tr>
                    <td class="text-left" colspan="1"><b>Email</b></td>
                    <td class="text-left" colspan="5" ><?php echo $store->email;?></td>    
                </tr>
                <tr>
                    <td class="text-left" colspan="1"><b>Mobile Number</b></td>
                    <td class="text-left" colspan="5" ><?php echo $store->contact;?> , <?php echo $store->contact2;?></td>    
                </tr>
                <tr>
                    <td class="text-left" colspan="1"><b>Address</b></td>
                    <td class="text-left" colspan="5" ><?php echo $store->address;?></td>    
                </tr>
                <tr>
                   <td class="text-center" colspan="6" ><h2>ALL IMAGES</h2></td>
                </tr>   
                <tr>
                  <td><img style="width: 120px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $store->images;?>"  alt="image"    /></td>
                  <td><img style="width: 90px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $store->images2;?>"  alt="image"    /></td>
                  <td><img style="width: 90px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $store->images3;?>"  alt="image"    /></td>
                  <td><img style="width: 90px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $store->images4;?>"  alt="image"    /></td>
                  <td><img style="width: 90px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $store->images5;?>"  alt="image"    /></td>
                  <td><img style="width: 90px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $store->images6;?>"  alt="image"    /></td>

                </tr>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
 </div>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
