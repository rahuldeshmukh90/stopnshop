<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">

  <div class="page-header">
         <?php if($this->session->flashdata('success')): ?>
                                
                                   
                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('success');?></a>
                                    </div>                                   
                                  
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('error')):?>
                                  
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"> <?php echo $this->session->flashdata('error');?></a>
                                        </div>
                                    
                                <?php endif;?>



                              <?php if($this->session->flashdata('w_success')): ?>
                                <ul class="woocommerce-message">
                                  <li>

                                    <div class="alert alert-dismissible alert-danger">
                                       <button type="button" class="close" data-dismiss="alert">&times;</button>
                                       <strong>Success : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_success');?></a>
                                    </div>
                                   
                                                                        
                                  </li>
                                </ul>
                                        
                                          
                                
                                <?php elseif($this->session->flashdata('w_error')):?>
                                    <ul class="woocommerce-error">
                                      <li>
                                        <div class="alert alert-dismissible alert-danger">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <strong>Error : </strong> <a href="#" class="alert-link"><?php echo $this->session->flashdata('w_error');?></a>
                                       </div>
                                        
                                      </li>
                                    </ul>
                                    
                              <?php endif;?>
     <div class="container-fluid">
      <br />
      
      <h1>Store Detail</h1>
      
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="">Store Detail</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i> Store Detail</h3>
      </div>
      <div class="panel-body">
       
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">


            <table class="table table-bordered table-hover">
              <thead>
                <tr>
                  <td class="text-left"> 
                      Image
                  </td>
                  <td class="text-left"> 
                      Store Name
                  </td>
                  <td class="text-left">
                      latitude
                  </td>
                  <td class="text-left">
                      longitude
                  </td>
                 
                  <td class="text-left">   
                      Address
                  </td>
                  <td class="text-left">   
                      Email
                  </td>
                  <td class="text-left">   
                      Contact-1
                  </td>
                  <td class="text-left">   
                      Contact-2
                  </td>
                  <td class="text-left">   
                      Detail
                  </td>
                  <td class="text-right">Action</td>
                </tr>
              </thead>
              <tbody>

                

                <tr>
                    <td class="text-center">  
			

                                <img style="width: 90px;height: 90px;" src="<?php echo base_url();?>upload/<?php echo $product->images;?>"  alt="image"   class="img-thumbnail" />
                            
							
							</td>
                    <td class="text-left"><?php echo $product->name; ?></td>
                    <!-- <td><img src="<?php echo base_url();?>assets/upload/<?php echo $products->pro_image;?>"</td> -->
                    <td class="text-left"><?php echo $product->latitude;?></td>
                    <td class="text-left">
                          <!-- <span style="text-decoration: line-through;">100.0000</span> -->

                         <?php echo $product->longitude;?>
                    </td>
                   
                    <td class="text-left"><?php echo $product->address ; ?></td>
                    <td class="text-left"><?php echo $product->email ; ?></td>
                    <td class="text-left"><?php echo $product->contact ; ?></td>
                    <td class="text-left"><?php echo $product->contact2 ; ?></td>
                    <td class="text-left"><?php echo anchor("customers/store_detail/$product->id",' View ',['class'=>'btn btn-info'])?>
</td>
                    <td class="text-right">
              
                      <?php echo anchor("customers/edit_store_view/$product->id",'<i class="fa fa-pencil"></i>',['class'=>'btn btn-primary'])?>

                   </td>
                </tr>

              


              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
 </div>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
