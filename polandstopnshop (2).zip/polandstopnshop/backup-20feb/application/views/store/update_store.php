<?php $this->load->view('template/head'); ?>

<!-- <script src="http://www.aorank.com/tutorial/multiple_image_upload_demo/script.js"></script> -->
<body>
<div id="container">
<?php  $this->session->userdata('id'); ?>
<?php $this->load->view('template/head'); ?>
<?php $this->load->view('template/left_sidebar'); ?>

<div id="content">
  <div class="page-header">
    <div class="container-fluid">

      <h1>Edit Store Detail</h1>
     
    </div>
    <div class="container-fluid">
      <div class="pull-right">
       <!--  <button type="submit" form="" data-toggle="tooltip" title="Save" class="btn btn-primary"><i class="fa fa-save"></i></button> -->
    <!--     <a href="" data-toggle="tooltip" title="Cancel" class="btn btn-default"><i class="fa fa-reply"></i></a> --></div>

      <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('customers/store'); ?>">Store Detail</a></li>
                <li><a href="">Edit Store Detail</a></li>
      </ul>
    </div>
    
    
  </div>




  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Edit Store Detail</h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo site_url('customers/update_store'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Store</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">
                                <div class="" id="">

                
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Name</label>
                    
                    <div class="col-sm-10">
                      <input type="hidden" name="id"  value="<?php echo $store->id;?>" class="form-control" />

                      <input type="text" name="name"  value="<?php echo $store->name;?>" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-latitude">Latitude</label>
                    
                    <div class="col-sm-10">

                      <input type="text" name="latitude" value="<?php echo $store->latitude;?>"  class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">

                    <label class="col-sm-2 control-label" for="input-longitude">Longitude</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="longitude"  value="<?php echo $store->longitude;?>"  class="form-control" />
                    </div>

                  </div>

                 
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-address">Address</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="address" value="<?php echo $store->address;?>"  class="form-control" />
                    </div>

                  </div>
                   
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-email">Email</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="email" value="<?php echo $store->email;?>"  class="form-control" />
                    </div>

                  </div>
                  
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-contact">Contact-1</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="contact" value="<?php echo $store->contact;?>"  class="form-control" />
                    </div>

                  </div>
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-contact">Contact-2</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="contact2" value="<?php echo $store->contact2;?>"  class="form-control" />
                    </div>

                  </div>

              <div class="col-sm-12" style="margin-left: 10%;" > 

                  <div class="col-sm-4">
                  <div class="col-sm-12">
                     <label class="control-label" for="input-contact">Image-1</label>
                  </div>
                    <div class="col-sm-12" >
                    <img class="img-thumbnail" style="width: 150px; height: 100px;" src="<?php echo base_url();?>upload/<?php echo $store->images;?>">
                    </div>
                    <div class="col-sm-12" style="margin-top: 10px" >
                      <input type="file" name="new_images"  />
                      <input type="hidden" name="old_images" value="<?php echo $store->images;?>"/>
                    </div>

                  </div>


                  <div class="col-sm-4">
                  <div class="col-sm-12">
                     <label class="control-label" for="input-contact">Image-2</label>
                  </div>   
                    <img class="img-thumbnail" style="width: 150px; height: 100px;" src="<?php echo base_url();?>upload/<?php echo $store->images2;?>">
                    <div class="col-sm-10" style="margin-top: 10px" >
                      <input type="file" name="new_images2" />
                      <input type="hidden" name="old_images2" value="<?php echo $store->images2;?>"/>
                    </div>

                  </div>

                   <div class="col-sm-4">
                  <div class="col-sm-12">
                     <label class="control-label" for="input-contact">Image-3</label>
                  </div>
                    <img class="img-thumbnail" style="width: 150px; height: 100px;" src="<?php echo base_url();?>upload/<?php echo $store->images3;?>">
                    <div class="col-sm-10" style="margin-top: 10px">
                      <input type="file" name="new_images3"  />
                      <input type="hidden" name="old_images3" value="<?php echo $store->images3;?>"/>
                    </div>

                  </div>

                  <div class="col-sm-12" style="margin-top: 20px"></div>
                  <div class="col-sm-4">
                  <div class="col-sm-12">
                     <label class="control-label" for="input-contact">Image-4</label>
                  </div>
                    <img class="img-thumbnail" style="width: 150px; height: 100px;" src="<?php echo base_url();?>upload/<?php echo $store->images4;?>">
                    <div class="col-sm-10" style="margin-top: 10px" >
                      <input type="file" name="new_images4"   />
                      <input type="hidden" name="old_images4" value="<?php echo $store->images4;?>"/>
                    </div>

                  </div>

                   <div class="col-sm-4">
                  <div class="col-sm-12">
                     <label class="control-label" for="input-contact">Image-5</label>
                  </div>
                    <img class="img-thumbnail" style="width: 150px; height: 100px;" src="<?php echo base_url();?>upload/<?php echo $store->images5;?>">
                    <div class="col-sm-10" style="margin-top: 10px" >
                      <input type="file" name="new_images5"   />
                      <input type="hidden" name="old_images5" value="<?php echo $store->images5;?>"/>
                    </div>

                  </div>


                  <div class="col-sm-4">
                  <div class="col-sm-12">
                     <label class="control-label" for="input-contact">Image-5</label>
                  </div>
                    <img class="img-thumbnail" style="width: 150px; height: 100px;" src="<?php echo base_url();?>upload/<?php echo $store->images6;?>">
                    <div class="col-sm-10" style="margin-top: 10px" >
                      <input type="file" name="new_images6"  />
                      <input type="hidden" name="old_images6" value="<?php echo $store->images6;?>"/>
                    </div>

                  </div>

              </div>
                  

                

                  <div class="form-group" >
                  
                    
                    <div class="col-sm-10" style="margin-top: 50px" >

                      <input type="submit" value="Update Store" class="btn btn-primary">

                      <a class="btn btn-default" href="<?php echo site_url('customers/store'); ?>">Cancel</a>
                    </div>
                  </div>
                 

              
                </div>
                               
              </div>
            </div>
         </div>
        </form>
      </div>
    </div>
  </div>
 <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    name: "required",
                    latitude:"required",
                    longitude:"required",
                    address:"address",
                    email:{
                              required: true,
                              email: true
                            },
                    contact:{
                              required: true,
                              minlength: 10,
                              maxlength: 10,
                              digits: true
                            },
                    address: "required",
                    file  : "required",
                   
                   
                },
                messages: {
                    name: "<P class='text-danger'>Please enter your name</p>",
                    latitude: "<P class='text-danger'>This field is required.</p>",
                    longitude: "<P class='text-danger'>This field is required.</p>",
                    address: "<P class='text-danger'>Please enter your address.</p>",
                    email:{
                              required: "<P class='text-danger'>Please fill email address</p>",
                                 email: "<P class='text-danger'>Please provide valid email address</p>"
                            },
                    contact:{
                              required:  "<P class='text-danger'>Please fill contact number.</p>",
                              minlength: "<P class='text-danger'>Phone number must be 10 digit long </p></p></p>",
                              maxlength: "<P class='text-danger'>Phone number must be 10 digit long</p></p>",
                              digits:    "<P class='text-danger'>Enter numeric value.</p>"
                            },
                    file: "<P class='text-danger'>Please Select Image</p>",
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>
</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
