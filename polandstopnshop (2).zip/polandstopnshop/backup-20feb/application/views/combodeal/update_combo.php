<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header'); ?>
<?php $this->load->view('template/left_sidebar.php'); ?>
<div id="content">
  <div class="page-header">
       <div class="container-fluid">
     
      <h1>Products</h1>
     
    </div>
      <div class="container-fluid">
      <div class="pull-right">
        <!-- <button type="submit" form="form-product" data-toggle="tooltip" title="Save" class="btn btn-primary"><i class="fa fa-save"></i></button> -->
        <a href="" data-toggle="tooltip" title="Cancel" class="btn btn-default"><i class="fa fa-reply"></i></a></div>
     
      <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('products/all_products'); ?>">Products</a></li>
                <li><a href="">Edit Products</a></li>
      </ul>
    </div>
   
  </div>

     <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i>Edit Product</h3>
      </div>
      <div class="panel-body">
        <form  id="add_form" action="<?php echo site_url('combo/edit_combo'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Edit Products Detail</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">

               <div class="" id="">

                   <div >
                    <div class="">
                      <input type="hidden" name="comboid"  value="<?php echo $products->id;?>" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Product Name</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="name"  value="<?php echo $products->name;?>" class="form-control" />
                    </div>

                  </div>

                   <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-image">Change image</label>
                    
                    <div class="col-sm-10">
                      <img src="<?php echo base_url();?>upload/<?php echo $products->image;?>" alt="" class="img-thumbnail"  width="100"/>
                    </div>

                     
                    <label class="col-sm-2 " ></label>
                    <div class="col-sm-10">
                       
                      <input type="file" name="image"  />
                      <input type="hidden" name="old_images" value="<?php echo $products->image;?>"/>
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-meta-title1">Price</label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="price" value="<?php echo $products->price;?>" placeholder="price" class="form-control" />
                    </div>

                  </div>
                  

                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-description1">Description</label>
                    
                    <div class="col-sm-10">
                      <textarea name="description"  class="form-control summernote"><?php echo $products->description;?></textarea>
                    </div>

                  </div>
                  
                  <div class="form-group">
                     <table class="table">
                      <tbody>

                        <?php 
                              foreach ($dealproduct->result() as $detail) {
                                
                        ?>
                             <tr>
                                
                                <td class="text-left">
                                  
                                  <img width="70px" class="img-responsive" src="<?php echo base_url();?>upload/<?php echo $detail->image;?>"  alt="image"    />
                                   
                                </td>
                                <td class="text-left">
                                   <input type="hidden" name="detailid[]" value="<?php echo $detail->id; ?>">
                                   <input type="hidden" name="image1[]" value="<?php echo $detail->image; ?>">
                                   <input type="file"   name="new_image[]" value"<?php echo $detail->image; ?>" >  
                                </td>
                                <td class="text-left">
                                  
                                  <input type="text" name="productname[]" value="<?php echo $detail->product_name; ?>"> 
                                  
                                </td>
                                <td class="text-left">
                                  
                                  <input type="text" name="productdescription[]" value="<?php echo $detail->description; ?>">
                                </td>    
                                <td class="text-left">
                                   <input type="text" name="productprice[]" value="<?php echo $detail->price; ?>">
                                </td>
                                    
                             </tr>
                     
                        <?php } ?>

                      </tbody>
                    </table> 
                  </div>
                  
                  <div class="form-group">
                  
                    
                    <div class="col-sm-10">
                      <input type="submit" value="Update Combo" class="btn btn-primary">

                      <a class="btn btn-default" href="<?php echo site_url('combo/combolist'); ?>">Cancel</a>
                    </div>
                  </div>
                 

              
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>

<script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    name: "required",
                    categoryId: "required",
                   
                    
                    price:{
                              required: true,
                             
                              number: true,
                              //digits: true
                            },
                    description: "required",        
                            
                    
                   
                   
                },
                messages: {
                    name: "<P class='text-danger'>Please enter your name</p>",
                    categoryId: "<P class='text-danger'>please choose category</p>",
                   
                    
                    price:{
                              required:  "<P class='text-danger'>price is required..</p>",
                              
                              number:    "<P class='text-danger'>Please enter a valid number.</p>"
                            },
                    
                    description: "<P class='text-danger'>description field is required.</p>",

                   
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>


  </div>
<footer id="footer"><a href="#">shop App</a> &copy; 2017-2018 All Rights Reserved</footer></div>
</body></html>
