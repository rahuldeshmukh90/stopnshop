<?php $this->load->view('template/head'); ?>

<body>
<div id="container">
<?php  $this->session->userdata('admin_email'); ?>
<?php $this->load->view('template/header.php'); ?>
<?php $this->load->view('template/left_sidebar.php'); ?>
<div id="content">
  <div class="page-header">
      <div class="container-fluid">
    
      <h1>Products</h1>
      
    </div>

    <div class="container-fluid">
        <div class="pull-right">
        <!-- <button type="submit" form="form-product" data-toggle="tooltip" title="Save" class="btn btn-primary"><i class="fa fa-save"></i></button> -->
       </div>
      <ul class="breadcrumb" style="margin-left: -8px">
                <li><a href="<?php echo site_url('admin_login/dashboard'); ?>">Home</a></li>
                <li><a href="<?php echo site_url('combo'); ?>">Combo Products</a></li>
                <li><a href="">Add Combo Product</a></li>
              </ul>
    </div>
  
  </div>

<style type="text/css">
.form-control {
     width:93%;
}
</style>


  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i>Add Combo Deal</h3>
      </div>
      <div class="panel-body">
        <form id="add_form" action="<?php echo site_url('combo/add'); ?>" method="post" enctype="multipart/form-data" id="form-product" class="form-horizontal">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#tab-general" data-toggle="tab">Combo Details</a></li>
           
          </ul>
          <div class="tab-content">
            <div class="tab-pane active" id="tab-general">
             
              <div class="tab-content">
                  <div class="" id="">
                    <div class="form-group required">
                      
                      <label class="col-sm-2 control-label" for="input-name">Name</label>
                      
                      <div class="col-sm-10">
                        <input type="text" name="name" value="" placeholder="Products Name" class="form-control" />
                      </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-price">Price </label>
                    
                    <div class="col-sm-10">
                      <input type="text" name="price" value="" placeholder="Products Price" class="form-control" />
                    </div>

                  </div>

                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-image">Image</label>
                    
                    <div class="col-sm-10">
                      <input type="file" name="image"/>
                    </div>

                  </div>


                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-description">Description</label>
                    
                    <div class="col-sm-10">
                      <textarea name="description" placeholder="Description" class="form-control summernote"></textarea>
                    </div>

                  </div>

                  <div class="form-group" >
                        <h3 align="center"> ADD MULTIPLE PRODUCTS </h3>       
                  </div>

                  <div class="panel panel-default">
  
                  <div class="panel-body">
                    
                    <div id="education_fields">
                            
                    </div>
                  <div class="col-sm-3 nopadding">
                    <div class="form-group">
                      <input type="text" class="form-control" id="Schoolname" name="productname[]" value="" placeholder="Product Name">
                    </div>
                  </div>
                  <div class="col-sm-3 nopadding">
                    <div class="form-group">
                       <input type="text" class="form-control" id="Degree" name="productdescription[]" value="" placeholder="Description">  
                    </div>
                  </div>
                  <div class="col-sm-3 nopadding">
                    <div class="form-group">
                      
                    <input type="file"  id="Major" name="image1[]">
                    </div>
                  </div>
                  <div class="col-sm-3 nopadding">
                  <div class="input-group-btn">
                          <button style="margin-top:15px" class="btn btn-success" type="button"  onclick="education_fields();"> <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> </button>
                  </div>
                  </div>
                  <div class="clear"></div>
                    
                    </div>
                    
                  </div>

                  <!-- <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-meta-description1">Meta Tag Description</label>
                    <div class="col-sm-10">
                      <textarea name="description1" rows="5" placeholder="Meta Tag Description" class="form-control"></textarea>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-meta-keyword1">Meta Tag Keywords</label>
                    
                    <div class="col-sm-10">
                      <textarea name="keyword" rows="5" placeholder="Meta Tag Keywords" class="form-control"></textarea>
                    </div>
                  </div> -->

                  <div class="form-group">
                  
                    
                    <div class="col-sm-10">
                       

                      <input type="submit" name="submit" value="Add Combo" class="btn btn-primary">

                      <a class="btn btn-default" href="<?php echo site_url('combo/combolist'); ?>">Cancel</a>
                    </div>
                  </div>
                 

              
                </div>
                               
              </div>
            </div>


        
          </div>
        </form>
      </div>
    </div>
  </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script type="text/javascript">

var room = 1;
function education_fields() {
 
    room++;
    var objTo = document.getElementById('education_fields')
    var divtest = document.createElement("div");
  divtest.setAttribute("class", "form-group removeclass"+room);
  var rdiv = 'removeclass'+room;
    divtest.innerHTML = '<div class="col-sm-3 nopadding"><div class="form-group"> <input type="text" class="form-control" id="Schoolname" name="productname[]" value="" placeholder="Product Name"></div></div><div class="col-sm-3 nopadding"><div class="form-group"> <input type="text" class="form-control" id="Degree" name="productdescription[]" value="" placeholder="Description"></div></div><div class="col-sm-3 nopadding"><div class="form-group"> <input type="file" id="Major" name="image1[]"></div></div><div class="col-sm-3 nopadding"><div class="form-group"><div class="input-group"><div class="input-group-btn"> <button class="btn btn-danger" type="button" onclick="remove_education_fields('+ room +');"> <span class="glyphicon glyphicon-minus" aria-hidden="true"></span> </button></div></div></div></div><div class="clear"></div>';
    
    objTo.appendChild(divtest)
}
   function remove_education_fields(rid) {
     $('.removeclass'+rid).remove();
   }

</script>

<script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.validate.min.js"></script> 
<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#add_form").validate({
                rules: {
                    name: "required",
                    price:{
                              required: true,
                              number: true,
                              
                              digits: true
                            },
                    description: "required",
                    
                },
                messages: {
                    name: "<P class='text-danger'>Please enter product name</p>",
                    categoryId: "<P class='text-danger'>please choose category</p>",
                    //image: "<P class='text-danger'>image is required</p>",
                    
                    price:{
                              required:  "<P class='text-danger'>Please enter price..</p>",
                             
                              digits:    "<P class='text-danger'>Enter numeric value.</p>"
                            },
                    
                    description: "<P class='text-danger'>Description field is required.</p>",

                   
                    
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);

</script>



</div>
<footer id="footer"><a href="#">shop app</a> &copy; 2017-2018 All Rights Reserved.<br /></footer></div>
</body></html>
