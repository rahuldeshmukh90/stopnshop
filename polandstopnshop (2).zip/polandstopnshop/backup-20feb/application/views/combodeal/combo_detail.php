<?php $this->load->view('template/head'); ?>
<body>
<div id="container">
<?php  $this->load->view('template/header'); ?>
<?php  $this->load->view('template/left_sidebar'); ?>

<div id="content">
   
  <div class="page-header">
        
     <div class="container-fluid">
      <br />
      
      <h1>Combo Products Detail</h1>
      
    </div>
    <div class="container-fluid">
      
      <ul class="breadcrumb" style="margin-left: -8px" >
                <li><a href="">Home</a></li>
                <li><a href="">Combo Detail</a></li>
              </ul>
    </div>
   
  </div>
  <div class="container-fluid">
            <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-list"></i>Combo Detail</h3>
      </div>
      <div class="panel-body">
        <div class="col-sm-4">
           <img width="100%" class="img-responsive" src="<?php echo base_url();?>upload/<?php echo $product->image;?>"  alt="image"    />
        </div> 
        <div class="col-sm-8">
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <div class="col-sm-12"><h3 class="text-center"><?php echo strtoupper($product->name); ?></h3></div> 

            <table class="table">
             
              <tbody>
                 <tr>
                    <td class="text-left"><b>Name</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->name;?></td>    
                </tr>
             
               
                <tr>
                    <td class="text-left" colspan="1"><b>Price</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->price;?></td>    
                </tr>
                <!--<tr>
                    <td class="text-left" colspan="1"><b>Quantity</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->qnty;?> , </td>    
                </tr>-->
                 <tr>
                    <td class="text-left" colspan="1"><b>Description</b></td>
                    <td class="text-left" colspan="5" ><?php echo $product->description;?></td>    
                </tr>
                
              </tbody>
            </table>

            

          </div>

        </form>
       </div> 
      </div>
      <!--for combo deal related product -->

      <div class="panel-body">
         
        <div class="col-sm-12">
        <form action="" method="post" enctype="multipart/form-data" id="form-product">
          <div class="table-responsive">
            <div class="col-sm-12"><h4 class="text-center" style="padding:20px"><i>Combo Deal Related Products</i> </h4></div> 

            <table class="table">
             
              <tr style="background:cornflowerblue">
                <th>PRODUCT IMAGE</th>
                <th>PRODUCT NAME</th>
                <th>DESCRIPTION</th>
                <th>PRICE</th>
              </tr>
              <tbody>

                <?php 
                      foreach ($product_detail->result() as $detail) {
                        
                ?>
                 <tr>
                    <td class="text-left">
                      <img width="100px" class="img-responsive" src="<?php echo base_url();?>upload/<?php echo $detail->image;?>"  alt="image"    />
                    </td>
                    <td class="text-left"><?php echo $detail->product_name; ?></td>
                    <td class="text-left"><?php echo $detail->description; ?></td>    
                    <td class="text-left"><?php echo $detail->price; ?></td>    
                </tr>
             
             <?php } ?>
              </tbody>
            </table>

          </div>
         </form>
       </div> 
      </div>
    </div>
  </div>
 </div>
<footer id="footer"><a href="#">ShopApp</a> &copy; 2009-2017 All Rights Reserved.</footer></div>
</body></html>
