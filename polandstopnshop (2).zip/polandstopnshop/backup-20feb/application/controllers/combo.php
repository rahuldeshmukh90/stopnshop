<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  

class Combo extends CI_Controller
{
 
    function __construct()
       {
        
        parent::__construct();
        $this->load->model('combo_model');  
        
       }

    function index(){
       
       redirect('combo/combolist');

    }

    function combolist(){

        $this->load->library('pagination');
        $config = [
              'base_url'=>base_url('index.php/combo/combolist'),
              'per_page'=>5,
              'total_rows'=>$this->combo_model->total_combo_product(),
              'full_tag_open'=>"<ul class='pagination'>",
              'full_tag_close'=>"</ul>",
              'first_tag_open'=>'<li>',
              'uri_segment'   =>3,
              'first_tag_close'=>'</li>',
              'last_tag_open'=>'<li>',
              'last_tag_close'=>'</li>',
              'next_tag_open'=>'<li>',
              'next_tag_close'=>'</li>',
              'prev_tag_open'=>'<li>',
              'prev_tag_close'=>'</li>',
              'num_tag_open'=>'<li>',
              'num_tag_close'=>'</li>',
              'cur_tag_open'=>"<li class='active'><a>",
              'cur_tag_close'=>'</a></li>',
        ];

        $this->pagination->initialize($config); 
        
        $data['list'] = $this->combo_model->getcombolist( $config['per_page'], $this->uri->segment(3)); 
       
        //$data['list'] = $this->combo_model->getcombolist();

       $this->load->view('combodeal/combo_list',$data);

    }

    function addcomboView(){

      $this->load->view('combodeal/add_combo');

    }
    function add(){



                $f_name = $_FILES['image']['name'];
                $f_tmp = $_FILES['image']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile="";
                if($f_name){
                $f_newfile = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
                date_default_timezone_set("Asia/Kolkata");
                $current_date=date("Y-m-d h:i:s");

       $product_data = array(

                      'name'         => $this->input->post('name'),
                      'price'        => $this->input->post('price'), 
                      'image'        => $f_newfile, 
                      'description'  => $this->input->post('description'),
                      'addedDate'    => $current_date,
                      'product_type' => 'combo'
                    );

        $product_id          = $this->combo_model->save_and_get_id($product_data);
        $productname         = $this->input->post('productname'); 
        $productprice        = $this->input->post('productprice');  
        $productdescription  = $this->input->post('productdescription');  
        
     

       if(!empty($productname)){

                    $final_array = array();
                    $length = count($productname);
                          for($i = 0; $i < $length; $i++) {

                            $f_name1 = $_FILES['image1']['name'][$i];
                            $f_tmp1  = $_FILES['image1']['tmp_name'][$i];

                            $f_extension1 = explode('.',$f_name1); //To breaks the string into array
                            $f_extension1 = strtolower(end($f_extension1)); //end() is used to retrun a last element to the array
                            $f_newfile1   = "";
                            if($f_name1){
                            $f_newfile1 = uniqid().'.'.$f_extension1; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                            $store1 = "upload/" . $f_newfile1;
                            $file2  =  move_uploaded_file($f_tmp1,$store1);
                            }
                            
                            $name        = $final_array[$i]['productname']  = $productname[$i];
                            $price       = $final_array[$i]['productname']  = $productprice[$i];
                            $image       = $final_array[$i]['productname']  = $productimage[$i];
                            $description = $final_array[$i]['productname']  = $productdescription[$i];
                           
                            $detail_data = array(
                                    
                                    'dealId'       => $product_id,
                                    'product_name' => $name,
                                    'price'        => '400.00',
                                    'image'        => $f_newfile1,
                                    'description'  => $description,
                                    'addedDate'    => $current_date
                                    
                            );
                               
                      $this->combo_model->save_combo_details($detail_data);  
                             
                }

           } 

      redirect('combo/combolist');
       
    }

    function delete_combodeal($id) {


      $id = $this->uri->segment(3);
      //$this->load->model('product_model');
      if($this->combo_model->delete($id))
      {
        $this->session->set_flashdata('success', 'Delete product successfully.'); 
        
      }else{

        $this->session->set_flashdata('error', 'Product is not deleted.'); 
      }

      // $this->load->view('edit_product');

      redirect('combo/combolist');
    }

    function combo_detail(){

        $id = $this->uri->segment(3); 

        $data['product'] = $this->combo_model->get_product_by_id($id);

        $data['product_detail'] = $this->combo_model->get_productdetail_by_id($id);         

        $this->load->view('combodeal/combo_detail' ,$data);


    }

    public function editcomboview($row_id){


      $id = $this->uri->segment(3);

      $data['products'] = $this->combo_model->get_combo_row($id);
      
      $data['dealproduct'] = $this->combo_model->get_productdetail_by_id($row_id);

      if($data)
      {
        $this->load->view("combodeal/update_combo",$data);
      } 

    }

    public function edit_combo(){

        if(empty($_FILES['image']['name']))
          {
             
             $f_newfile01 = $this->input->post('old_images'); 

          }else{
    
                $f_name = $_FILES['image']['name'];
                $f_tmp = $_FILES['image']['tmp_name'];
                $f_extension = explode('.',$f_name); //To breaks the string into array
                $f_extension = strtolower(end($f_extension)); //end() is used to retrun a last element to the array
                $f_newfile01 ="";
                if($f_name){
                $f_newfile01 = uniqid().'.'.$f_extension; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                $store = "upload/" . $f_newfile01;
                $file1 =  move_uploaded_file($f_tmp,$store);
                }
        }

                date_default_timezone_set("Asia/Kolkata");
                $current_date=date("Y-m-d h:i:s");

                $product_data = array(

                      'name'         => $this->input->post('name'),
                      'price'        => $this->input->post('price'), 
                      'image'        => $f_newfile01, 
                      'description'  => $this->input->post('description'),
                      'addedDate'    => $current_date,
                      'product_type' => 'combo'

                    );
        //print_r($product_data); die();
        $comboid             = $this->input->post('comboid');       
        $product_id          = $this->combo_model->update_and_get_id($product_data,$comboid);

        $productname         = $this->input->post('productname'); 
        $productprice        = $this->input->post('productprice');  
        $productdescription  = $this->input->post('productdescription');  
        $detailid            = $this->input->post('detailid');           
        $productimage        = $this->input->post('image1');

       if(!empty($productname)){

                    $final_array = array();
                    $length = count($productname);
                          for($i = 0; $i < $length; $i++) {
 
                            $image   = $final_array[$i]['productname']  = $productimage[$i];
                            
                            if(empty($_FILES['new_image']['name'][$i]))
                            {
                              
                                // $f_newfile1 = $image; 
                                //$f_newfile1  = $this->input->post('image1')[$i]; 
                                $f_newfile1 = $image;

                            }else{

                                    $f_name1 = $_FILES['new_image']['name'][$i];
                                    $f_tmp1  = $_FILES['new_image']['tmp_name'][$i];

                                    $f_extension1 = explode('.',$f_name1); //To breaks the string into array
                                    $f_extension1 = strtolower(end($f_extension1)); //end() is used to retrun a last element to the array
                                    $f_newfile1   = "";
                                    if($f_name1){
                                    $f_newfile1 = uniqid().'.'.$f_extension1; // It`s use to stop overriding if the image will be same then uniqid() will generate the unique name
                                    $store1 = "upload/" . $f_newfile1;
                                    $file2  =  move_uploaded_file($f_tmp1,$store1);
                                    }
                            }  
                            
                            $id          = $final_array[$i]['productname']  = $detailid[$i];
                            $name        = $final_array[$i]['productname']  = $productname[$i];
                            $price       = $final_array[$i]['productname']  = $productprice[$i];
                            $description = $final_array[$i]['productname']  = $productdescription[$i];
                           
                            $detail_data = array(
                                    
                                    // 'dealId'       => $product_id,
                                    'product_name' => $name,
                                    'price'        => '400.00',
                                    'image'        => $f_newfile1,
                                    'description'  => $description,
                                    'addedDate'    => $current_date
                                    
                            );

                     //print_r($detail_data); die();  
                     $this->combo_model->update_combo_details($detail_data,$id);  
                             
                }

                //print_r($detail_data); die();         

           } 

      redirect('combo/combolist');



      $data['r'] = $this->product_model->edit_products($id); 
      
      if ($data['r']) {
        
        $this->session->set_flashdata('success', 'Update data successfully.'); 
      
      }else{

        $this->session->set_flashdata('error', 'Update data successfully.'); 

      }
      
      redirect('products/all_products');
    } 


}