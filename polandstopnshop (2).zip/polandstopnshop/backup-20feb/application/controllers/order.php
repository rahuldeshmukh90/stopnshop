<?php

/**
* 
*/
class Order extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
        $this->load->model('order_model');  
	}

	function latestOrder(){
       
       $data['latestorder'] = $this->order_model->getlatestOrder();
       $this->load->view('dashboard' ,$data);
	}

	function order_detail(){

         $id = $this->uri->segment(3); 

         $data['order']        = $this->order_model->get_order_by_id($id);        
         $data['order_detail'] = $this->order_model->getOrderdetail($id);        
         
         $this->load->view('order/order_detail' ,$data);


    }

    function allorderlist(){
       //echo $this->order_model->total_order(); die();
        $this->load->library('pagination');

            $config = [

              'base_url'=>base_url('index.php/order/allorderlist'),
              'per_page'=>10,
              'total_rows'=>$this->order_model->total_order(),
              'full_tag_open'=>"<ul class='pagination'>",
              'full_tag_close'=>"</ul>",
              'first_tag_open'=>'<li>',
              'uri_segment'   =>3,
              'first_tag_close'=>'</li>',
              'last_tag_open'=>'<li>',
              'last_tag_close'=>'</li>',
              'next_tag_open'=>'<li>',
              'next_tag_close'=>'</li>',
              'prev_tag_open'=>'<li>',
              'prev_tag_close'=>'</li>',
              'num_tag_open'=>'<li>',
              'num_tag_close'=>'</li>',
              'cur_tag_open'=>"<li class='active'><a>",
              'cur_tag_close'=>'</a></li>',
            ];
  
        $this->pagination->initialize($config); 
    
        $data['list'] = $this->order_model->get_order( $config['per_page'], $this->uri->segment(3));     
        $this->load->view('order/orderlist' ,$data);
    }
/*-----------------FOR ORDER DETAIL---------------------------*/

    function orderdetail(){

        $id = $this->uri->segment(3); 

        // $data['order'] = $this->combo_model->get_order_by_id($id);

        // $data['order_detail'] = $this->combo_model->get_orderdetail_by_id($id);   

         $data['order']        = $this->order_model->get_order_by_id($id);        
         $data['order_detail'] = $this->order_model->getOrderdetail($id);       

        $this->load->view('order/order_detail' ,$data);

    }

/*-----------------GET WEEKLY REPORT OF ORDER-----------------------*/

   function weeklyorderreport(){

        $this->load->library('pagination');

            $config = [

              'base_url'=>base_url('index.php/order/weeklyorderreport'),
              'per_page'=>10,
              'total_rows'=>$this->order_model->total_weeklyorder(),
              'full_tag_open'=>"<ul class='pagination'>",
              'full_tag_close'=>"</ul>",
              'first_tag_open'=>'<li>',
              'uri_segment'   =>3,
              'first_tag_close'=>'</li>',
              'last_tag_open'=>'<li>',
              'last_tag_close'=>'</li>',
              'next_tag_open'=>'<li>',
              'next_tag_close'=>'</li>',
              'prev_tag_open'=>'<li>',
              'prev_tag_close'=>'</li>',
              'num_tag_open'=>'<li>',
              'num_tag_close'=>'</li>',
              'cur_tag_open'=>"<li class='active'><a>",
              'cur_tag_close'=>'</a></li>',
            ];
  
        $this->pagination->initialize($config); 
    
        $data['list']  = $this->order_model->weeklyorder( $config['per_page'], $this->uri->segment(3));  
       
        //$data['list']   = $this->order_model->weeklyorder();
       $this->load->view('order/weeklyorder' ,$data);

   }

/*-----------------GET MONTHLY REPORT OF ORDER-----------------------*/

   function monthlyorderreport(){

        $this->load->library('pagination');

            $config = [

              'base_url'=>base_url('index.php/order/monthlyorderreport'),
              'per_page'=>10,
              'total_rows'=>$this->order_model->total_monthlyorder(),
              'full_tag_open'=>"<ul class='pagination'>",
              'full_tag_close'=>"</ul>",
              'first_tag_open'=>'<li>',
              'uri_segment'   =>3,
              'first_tag_close'=>'</li>',
              'last_tag_open'=>'<li>',
              'last_tag_close'=>'</li>',
              'next_tag_open'=>'<li>',
              'next_tag_close'=>'</li>',
              'prev_tag_open'=>'<li>',
              'prev_tag_close'=>'</li>',
              'num_tag_open'=>'<li>',
              'num_tag_close'=>'</li>',
              'cur_tag_open'=>"<li class='active'><a>",
              'cur_tag_close'=>'</a></li>',
            ];
  
        $this->pagination->initialize($config); 
    
        $data['list']  = $this->order_model->monthlyorder( $config['per_page'], $this->uri->segment(3));  
       
        //$data['list']   = $this->order_model->weeklyorder();
       $this->load->view('order/weeklyorder' ,$data);

   } 

/*-----------------GET YEARLY REPORT OF ORDER-----------------------*/

   function yearlyorderreport(){

        $this->load->library('pagination');

            $config = [

              'base_url'=>base_url('index.php/order/yearlyorderreport'),
              'per_page'=>10,
              'total_rows'=>$this->order_model->total_yearlyorder(),
              'full_tag_open'=>"<ul class='pagination'>",
              'full_tag_close'=>"</ul>",
              'first_tag_open'=>'<li>',
              'uri_segment'   =>3,
              'first_tag_close'=>'</li>',
              'last_tag_open'=>'<li>',
              'last_tag_close'=>'</li>',
              'next_tag_open'=>'<li>',
              'next_tag_close'=>'</li>',
              'prev_tag_open'=>'<li>',
              'prev_tag_close'=>'</li>',
              'num_tag_open'=>'<li>',
              'num_tag_close'=>'</li>',
              'cur_tag_open'=>"<li class='active'><a>",
              'cur_tag_close'=>'</a></li>',
            ];
  
        $this->pagination->initialize($config); 
    
        $data['list']  = $this->order_model->yearlyorder( $config['per_page'], $this->uri->segment(3));  
       
        //$data['list']   = $this->order_model->weeklyorder();
        $this->load->view('order/weeklyorder' ,$data);

   }          

}

?>