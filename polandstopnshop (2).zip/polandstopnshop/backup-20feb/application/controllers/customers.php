<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  

class Customers extends CI_Controller
{
	 
                	public function __construct()
                    {
                        parent::__construct();

                        $this->load->model('customer_model');
                        
                    }

                    function index(){
                       
                       $this->load->view('login');

                    }

                    public function customer_view(){

                      $this->load->view('customer/add_customer');

                    }

                    public function add_customer(){

                         $this->load->model('customer_model');
                         $this->customer_model->add_customer();  
                          

                         if($this->customer_model->add_customer()){

                            $this->session->set_flashdata('success', 'Customer add successfully.'); 
                         }else{

                            $this->session->set_flashdata('error', ' Customer is not added'); 
                         } 
                         redirect('customers/customers_list');
                    }

                    public function customers_list(){

                    $this->load->model('customer_model');
                    $this->load->library('pagination');
                    
                    $config = [
                     
                              'base_url'=>base_url('index.php/customers/customers_list'),
                              'per_page'=>10,
                              'total_rows'=>$this->customer_model->total_customers(),
                              'full_tag_open'=>"<ul class='pagination'>",
                              'full_tag_close'=>"</ul>",
                              'first_tag_open'=>'<li>',
                              'uri_segment'   =>3,
                              'first_tag_close'=>'</li>',
                              'last_tag_open'=>'<li>',
                              'last_tag_close'=>'</li>',
                              'next_tag_open'=>'<li>',
                              'next_tag_close'=>'</li>',
                              'prev_tag_open'=>'<li>',
                              'prev_tag_close'=>'</li>',
                              'num_tag_open'=>'<li>',
                              'num_tag_close'=>'</li>',
                              'cur_tag_open'=>"<li class='active'><a>",
                              'cur_tag_close'=>'</a></li>',
                    ];
                  
                    $this->pagination->initialize($config); 
                    
                    $data['product'] = $this->customer_model->get_all_customers( $config['per_page'], $this->uri->segment(3));

                    //$this->load->view('product/product_list',$data);
                    //$data['product']=$this->customer_model->get_all_customers();   

                    $this->load->view('customer/customer_list',$data);


                    }

                    public function updatecustomer__view(){

                     $id = $this->uri->segment(3); 

                     $this->load->model('customer_model');

                     $data['customer'] = $this->customer_model->get_customer($id);
                      
                      if($data)
                       {
                        $this->load->view("customer/update_customer",$data);
                       } 

                    }

                    public function update_customers(){

                        $this->load->model('customer_model');
                    
                        $data['r'] = $this->customer_model->update_customer($id); 

                        if($data['r']){

                            $this->session->set_flashdata('success', 'Customer update successfully.'); 
                         }else{

                            $this->session->set_flashdata('error', ' Customer is not updated'); 
                         } 
      
                        redirect('customers/customers_list');
                    }

                    public function delete_customer($id) {


                        $id = $this->uri->segment(3);
                        $this->load->model('customer_model');
                        $this->customer_model->delete_customer($id);

                        if($this->customer_model->delete_customer($id)){

                            $this->session->set_flashdata('success', 'Customer delete successfully.'); 
                         }else{

                            $this->session->set_flashdata('error', ' Customer is not deleted'); 
                         }

                        // $this->load->view('edit_product');

                        redirect('customers/customers_list');
                    }

                    public function store(){

                    $this->load->model('customer_model');

                    $data['product']=$this->customer_model->get_store();
                    $data['temp'] = explode(',',$this->customer_model->get_image() );	 					

                    $this->load->view('store/store_list', $data);


                    }

                    public function edit_store_view(){

                      $id = $this->uri->segment(3); 

                      $data['store'] = $this->customer_model->get_store_by_id($id);
                      

                      if($data)
                       {
                         $this->load->view("store/update_store",$data);
                       } 

                    }

                     public function update_store(){

                    

                      $data['store']=$this->customer_model->update_store(); 

                       if($data['store']){

                            $this->session->set_flashdata('success', 'Update store.'); 
                         }else{

                            $this->session->set_flashdata('error', ' Store not updated'); 
                         }  

                      redirect('customers/store');


                    }

                     public function store_detail(){

                     $id = $this->uri->segment(3); 

                      $data['store'] = $this->customer_model->get_store_by_id($id);        
                     
                     $this->load->view('store/store_detail' ,$data);


                    }

                     public function store_image(){

                    $this->load->model('customer_model');

                   // echo $this->customer_model->get_store(); die();

                    $temp1['temp'] = explode(',',$this->customer_model->get_image() );					

                    $this->load->view('store_list',$temp1);


                    }

   

}
