<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  

class Request extends CI_Controller
{
 
    function __construct()
       {
          parent::__construct();
          $this->load->model('request_model');  
        
       }

    function index(){
       
     $this->load->view('request_detail');  
    }

    function request_list() {

      $this->load->library('pagination');
        $config = [
                'base_url'=>base_url('index.php/request/request_list'),
                'per_page'=>5,
                'total_rows'=>$this->request_model->total_request(),
                'full_tag_open'=>"<ul class='pagination'>",
                'full_tag_close'=>"</ul>",
                'first_tag_open'=>'<li>',
                'uri_segment'   =>3,
                'first_tag_close'=>'</li>',
                'last_tag_open'=>'<li>',
                'last_tag_close'=>'</li>',
                'next_tag_open'=>'<li>',
                'next_tag_close'=>'</li>',
                'prev_tag_open'=>'<li>',
                'prev_tag_close'=>'</li>',
                'num_tag_open'=>'<li>',
                'num_tag_close'=>'</li>',
                'cur_tag_open'=>"<li class='active'><a>",
                'cur_tag_close'=>'</a></li>',
      ];
    
      $this->pagination->initialize($config); 

      $data['request'] = $this->request_model->get_request_list( $config['per_page'], $this->uri->segment(3));

      //$data['request'] = $this->request_model->get_request_list();
    
      $this->load->view('request/request_detail', $data);
     
    }

    function update_gasview() {
     
     $id = $this->uri->segment(3); 

                    
    
      $data1['gas1'] = $this->gas_model->get_gas_row($id);

      //print_r($data); die();
                      
      
      $this->load->view("gas/update_gas", $data1);
       
     //$this->gas_model->update_gas_detail();
     
    }

    function update_gasdetail(){


      $this->gas_model->update_gas_detail(); 

	  if($this->gas_model->update_gas_detail()){

	        $this->session->set_flashdata('success', 'Update gas detail.'); 
	        
	  }else{

	        $this->session->set_flashdata('error', ' Gas detail not updated'); 
	        }  

      redirect('gas/gas_detail');



    }

}