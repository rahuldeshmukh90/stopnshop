<?php

/**
* 
*/
class Search_item extends CI_Controller
{
	

	function index()
	{
		
	}
	
	function search_products()
    {

	    $this->load->helper('form');
        // Retrieve the posted search term.
        $search_term = $this->input->post('search');
        if (!empty($search_term)) {
        
           return redirect("search_item/search_result/$search_term"); 	
        
        }else{

           redirect('products/all_products');
        }
        
    //    $this->load->model('search_model');

        // Use a model to retrieve the results.
     //   $data['results'] = $this->search_model->get_results($search_term);

        // Pass the results to the view.
     //   $this->load->view('search_products',$data);
    }
	
	function search_result( $search_term )
	{
		//echo "hgvjbdfgh"; die();
		$this->load->helper('form');
		$this->load->model('search_model');
		$this->load->library('pagination');
		
	$config = [
	            'base_url'=>base_url("index.php/search_item/search_result/$search_term"),
	            'per_page'=>5,
				'total_rows'=>$this->search_model->count_search_results($search_term),
				'full_tag_open'=>"<ul class='pagination'>",
				'full_tag_close'=>"</ul>",
				'first_tag_open'=>'<li>',
				'uri_segment'   =>4,
				'first_tag_close'=>'</li>',
				'last_tag_open'=>'<li>',
				'last_tag_close'=>'</li>',
				'next_tag_open'=>'<li>',
				'next_tag_close'=>'</li>',
				'prev_tag_open'=>'<li>',
				'prev_tag_close'=>'</li>',
				'num_tag_open'=>'<li>',
				'num_tag_close'=>'</li>',
				'cur_tag_open'=>"<li class='active'><a>",
				'cur_tag_close'=>'</a></li>',
	];
	
	$this->pagination->initialize($config);
	$data['results'] = $this->search_model->get_results($search_term, $config['per_page'], $this->uri->segment(4));
  return 	 $this->load->view('product/search_products',$data);	
	}

	function search_combo()
    {

	    $this->load->helper('form');
        // Retrieve the posted search term.
        $search_term1 = $this->input->post('search');
        if (!empty($search_term1)) {

           return redirect("search_item/search_comboresult/$search_term1"); 	
        }else{

            redirect('combo');
        }
        
    
    }
	
	function search_comboresult( $search_term1 )
	{

		$this->load->helper('form');
		$this->load->model('search_model');
		$this->load->model('combo_model');
		$this->load->library('pagination');
		
	$config = [
	            'base_url'=>base_url("index.php/search_item/search_comboresult/$search_term1"),
	            'per_page'=>5,
				'total_rows'=>$this->search_model->count_searchcombo_results($search_term1),
				'full_tag_open'=>"<ul class='pagination'>",
				'full_tag_close'=>"</ul>",
				'first_tag_open'=>'<li>',
				'uri_segment'   =>4,
				'first_tag_close'=>'</li>',
				'last_tag_open'=>'<li>',
				'last_tag_close'=>'</li>',
				'next_tag_open'=>'<li>',
				'next_tag_close'=>'</li>',
				'prev_tag_open'=>'<li>',
				'prev_tag_close'=>'</li>',
				'num_tag_open'=>'<li>',
				'num_tag_close'=>'</li>',
				'cur_tag_open'=>"<li class='active'><a>",
				'cur_tag_close'=>'</a></li>',
	];
	
	$this->pagination->initialize($config);
	$data['results'] = $this->search_model->get_comboresults($search_term1, $config['per_page'], $this->uri->segment(4));
    return $this->load->view('combodeal/search_combo',$data);	
	}

	function search_customer()
    {

	    $this->load->helper('form');
        // Retrieve the posted search term.
        $search_term2 = $this->input->post('search');
        if (!empty($search_term2)) {
        
           return redirect("search_item/search_customerresult/$search_term2"); 

        }else{

            redirect('customers/customers_list');
        }
        
    
    }
	
	function search_customerresult($search_term2)
	{

		$this->load->helper('form');
		$this->load->model('search_model');
		$this->load->library('pagination');
		
	$config = [
	            'base_url'=>base_url("index.php/search_item/search_customerresult/$search_term2"),
	            'per_page'=>10,
				'total_rows'=>$this->search_model->count_searchcustomer_results($search_term2),
				'full_tag_open'=>"<ul class='pagination'>",
				'full_tag_close'=>"</ul>",
				'first_tag_open'=>'<li>',
				'uri_segment'   =>4,
				'first_tag_close'=>'</li>',
				'last_tag_open'=>'<li>',
				'last_tag_close'=>'</li>',
				'next_tag_open'=>'<li>',
				'next_tag_close'=>'</li>',
				'prev_tag_open'=>'<li>',
				'prev_tag_close'=>'</li>',
				'num_tag_open'=>'<li>',
				'num_tag_close'=>'</li>',
				'cur_tag_open'=>"<li class='active'><a>",
				'cur_tag_close'=>'</a></li>',
	];
	
	$this->pagination->initialize($config);
	$data['customer'] = $this->search_model->get_customerresults($search_term2, $config['per_page'], $this->uri->segment(4));
    return $this->load->view('customer/search_customer',$data);	
	}

	function search_date()
    {

	    $this->load->helper('form');
		$this->load->model('search_model');
		$this->load->library('pagination');
		
	    $search_term = array(
							    'start_date' => $this->input->post('start_date'),
								'end_date'   => $this->input->post('end_date')
						    );
        $config = [
        	
	            'base_url'=>base_url("index.php/search_item/search_date"),
	            'per_page'=>10,
				'total_rows'=>$this->search_model->count_date_orderresults($search_term),
				'full_tag_open'=>"<ul class='pagination'>",
				'full_tag_close'=>"</ul>",
				'first_tag_open'=>'<li>',
				'uri_segment'   =>4,
				'first_tag_close'=>'</li>',
				'last_tag_open'=>'<li>',
				'last_tag_close'=>'</li>',
				'next_tag_open'=>'<li>',
				'next_tag_close'=>'</li>',
				'prev_tag_open'=>'<li>',
				'prev_tag_close'=>'</li>',
				'num_tag_open'=>'<li>',
				'num_tag_close'=>'</li>',
				'cur_tag_open'=>"<li class='active'><a>",
				'cur_tag_close'=>'</a></li>',
	];
	
	$this->pagination->initialize($config);
	$data['list'] = $this->search_model->get_orderresults($search_term, $config['per_page'], $this->uri->segment(4));

    return $this->load->view('order/searchorder',$data);
        
    }
/*-------search order by order number------------------------*/

function searchbyorderNumber(){

        $this->load->helper('form');
        // Retrieve the posted search term.
        $search_term = $this->input->post('ordernumber');
        return redirect("search_item/serchorderResult/$search_term");   
   }

 function serchorderResult( $search_term )
	{
		$this->load->helper('form');
		$this->load->model('search_model');
		$this->load->library('pagination');

        if (!empty($search_term)) {
        	
        	$config = [
	            'base_url'=>base_url("index.php/search_item/serchorderResult/$search_term"),
	            'per_page'=>5,
				'total_rows'=>$this->search_model->count_searchordernumber($search_term),
				'full_tag_open'=>"<ul class='pagination'>",
				'full_tag_close'=>"</ul>",
				'first_tag_open'=>'<li>',
				'uri_segment'   =>4,
				'first_tag_close'=>'</li>',
				'last_tag_open'=>'<li>',
				'last_tag_close'=>'</li>',
				'next_tag_open'=>'<li>',
				'next_tag_close'=>'</li>',
				'prev_tag_open'=>'<li>',
				'prev_tag_close'=>'</li>',
				'num_tag_open'=>'<li>',
				'num_tag_close'=>'</li>',
				'cur_tag_open'=>"<li class='active'><a>",
				'cur_tag_close'=>'</a></li>',
	];
	
	$this->pagination->initialize($config);
	$data['list'] = $this->search_model->getorderByordernumber($search_term, $config['per_page'], $this->uri->segment(4));
  return $this->load->view('order/weeklyorder',$data);	

        }else{

            redirect('order/allorderlist');
        }
		
	}
	
}