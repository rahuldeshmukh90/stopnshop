<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  

class Gas extends CI_Controller
{
 
    function __construct()
       {
          parent::__construct();
          $this->load->model('gas_model');  
        
       }

    function index(){
       
     $this->load->view('gas_detail');  
    }

    function gas_detail() {
     
     $data['gas'] = $this->gas_model->get_gas_detail();
     $this->load->view('gas/gas_detail', $data);
     
    }

    function update_gasview() {
     
     $id = $this->uri->segment(3); 

                    
    
      $data1['gas1'] = $this->gas_model->get_gas_row($id);

      //print_r($data); die();
                      
      
      $this->load->view("gas/update_gas", $data1);
       
     //$this->gas_model->update_gas_detail();
     
    }

    function update_gasdetail(){


      $this->gas_model->update_gas_detail(); 

	  if($this->gas_model->update_gas_detail()){

	        $this->session->set_flashdata('success', 'Update gas detail.'); 
	        
	  }else{

	        $this->session->set_flashdata('error', ' Gas detail not updated'); 
	        }  

      redirect('gas/gas_detail');



    }

}