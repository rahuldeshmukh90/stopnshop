<?php 

class Categories extends CI_Controller{


   public function __construct()
    {
        parent::__construct();
       
        
    }

    function index(){
       
       $this->load->view('category');

    }

    public function category_list(){

     $this->load->model('category_model');

     $data['category']=$this->category_model->all_categorys();

    
     $this->load->view('category/category_list',$data);
    
    }


    public function category_view(){

     $this->load->view('category/add_category');
    }

    public function add_category(){

     $this->load->model('category_model');

     $this->category_model->add_category();  
      
     if($this->category_model->add_category()){

        $this->session->set_flashdata('success', 'Category add successfully.'); 
     }else{

        $this->session->set_flashdata('error', ' Category is not added'); 
     }
      
     redirect('categories/category_list');
    }


    public function edit_cat_view(){

     $id = $this->uri->segment(3);

     $this->load->model('category_model');

       $data['category'] = $this->category_model->get_category($id);
        if($data)
       {
          $this->load->view("category/update_category",$data);
       } 
    }

    public function edit_category(){

       //echo $id = $this->uri->segment(3); die();

  	   $id = $this->input->post('id');
  	    
       $this->load->model('category_model');

       $data['r'] = $this->category_model->update_category($id); 
       
       if($data['r']){

        $this->session->set_flashdata('success', 'Update category successfully.'); 
     }else{

        $this->session->set_flashdata('error', 'Category is not updated'); 
     }
      
       redirect('categories/category_list');
    }


    function delete_category($id) {


      $id = $this->uri->segment(3);
      $this->load->model('category_model');
      $this->category_model->delete($id);
      
      if($this->product_model->delete()){

        $this->session->set_flashdata('success', 'Category delete successfully.'); 
     }else{

        $this->session->set_flashdata('error', 'Category not deleted'); 
     }

      redirect('categories/category_list');
    }


}
