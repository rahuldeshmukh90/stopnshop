<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  

class Products extends CI_Controller
{
 
    function __construct()
       {
          parent::__construct();
       
          $this->load->model('product_model');
       }

    function index(){
       
       $this->load->view('login');
    }

    
   public function add_products_view(){

         $this->load->model('category_model');

         $data['category'] = $this->category_model->all_categorys();

         $this->load->view('product/add_product', $data);
    }
    

    public function add_products(){

      


     $this->load->model('product_model');

     if($this->product_model->add_products()){

        $this->session->set_flashdata('success', 'Product add successfully.'); 
     }else{

        $this->session->set_flashdata('error', ' Product is not added'); 
     }
      
     redirect('products/all_products');
    }


    public function show_products(){

    $this->load->model('product_model');
    $data['product']=$this->product_model->all_products();   

    $this->load->view('all_products_list.php',$data);


    }

    public function all_products(){
     
    $this->load->library('pagination');
    $config = [
              'base_url'=>base_url('index.php/products/all_products'),
              'per_page'=>10,
              'total_rows'=>$this->product_model->total_products(),
              'full_tag_open'=>"<ul class='pagination'>",
              'full_tag_close'=>"</ul>",
              'first_tag_open'=>'<li>',
              'uri_segment'   =>3,
              'first_tag_close'=>'</li>',
              'last_tag_open'=>'<li>',
              'last_tag_close'=>'</li>',
              'next_tag_open'=>'<li>',
              'next_tag_close'=>'</li>',
              'prev_tag_open'=>'<li>',
              'prev_tag_close'=>'</li>',
              'num_tag_open'=>'<li>',
              'num_tag_close'=>'</li>',
              'cur_tag_open'=>"<li class='active'><a>",
              'cur_tag_close'=>'</a></li>',
    ];
  
  //echo $config['base_url']; die();

    $this->pagination->initialize($config); 
    $this->load->model('product_model');
    $data['product']=$this->product_model->all_products( $config['per_page'], $this->uri->segment(3));

    $this->load->view('product/product_list',$data);
    
    }


    public function edit_form_view(){

        $id = $this->uri->segment(3); 

        $this->load->model('category_model');

        $data['products'] = $this->product_model->get_products($id);
        $data['category'] =$this->category_model->all_categorys();
        if($data)
       {
          $this->load->view("product/update_product",$data);
       } 

    }


    public function edit_products(){

       //$id = $this->uri->segment(3);
       $this->load->model('product_model');
       $data['r'] = $this->product_model->edit_products($id); 
       if ($data['r']) {
        
        $this->session->set_flashdata('success', 'Update data successfully.'); 
       }else{

        $this->session->set_flashdata('error', 'Update data successfully.'); 
       }
      
       redirect('products/all_products');
    } 

   function delete_product($id) {


      $id = $this->uri->segment(3);
      $this->load->model('product_model');
      if($this->product_model->delete($id))
      {
        $this->session->set_flashdata('success', 'Delete product successfully.'); 
        
      }else{

        $this->session->set_flashdata('error', 'Product is not deleted.'); 
      }

      // $this->load->view('edit_product');

      redirect('products/all_products');
    }

   function import_view(){
  
    $this->load->view('product/import');


    }

    function product_detail(){

         $id = $this->uri->segment(3); 

         $data['product'] = $this->product_model->get_product_by_id($id);        
         
         $this->load->view('product/product_detail' ,$data);


    }

    

}