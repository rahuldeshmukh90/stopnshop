<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Uploadcsv extends CI_Controller {

public function __construct()
{
    parent::__construct();
    $this->load->helper('url');                    
    $this->load->model('Welcome_model','welcome');
}

public function index()
{
  //$this->data['view_data']= $this->welcome->view_data();
  //$this->load->view('excelimport', $this->data, FALSE);
  //$this->load->view('product/product_list');
  redirect('products/all_products');
}

//////////////////Import subscriber emails ////////////////////////////////
public function importbulkemail(){

  $this->load->view('excelimport');
}

public function import()
        {
          //$this->load->model('category_model');
   // $data['cate'] = $this->category_model->get_category_id();

         $query = $this->db->query("SELECT * FROM sa_category");

 
foreach($query->result_array() as $row){
     $cat_arry[] = $row['name'];
}




  if(isset($_POST["import"]))
    {

        $this->load->model('category_model');

        $r = $this->category_model->get_category_id();


        $filename=$_FILES["file"]["tmp_name"];
        //$_FILES["file"]["type"] = 'xls|xlsx|csv';
        //$configUpload['allowed_types'] = 'xls|xlsx|csv';
        if($_FILES["file"]["size"] > 0)
          {

            $file = fopen($filename, "r");
             while (($importdata = fgetcsv($file, 10000, ",")) !== FALSE)
             {
                  
                  if(is_numeric($importdata[3])){

                    // $importdata[3] = '';
                    if(in_array($importdata[1],$cat_arry)){
                      // $importdata[3] = '';
                      $ids = $this->category_model->get_info($importdata[1])->id;
                       $data = array(
                        'name'        => $importdata[0],
                        'categoryId'  => $ids,
                        'description' => $importdata[2],
                        'price'       => $importdata[3]
                        //'qnty'        => $importdata[4],
                       );

                       $insert = $this->welcome->insertCSV($data);
                    }

                    }  
                    
             

             }                    
            fclose($file);
        $this->session->set_flashdata('message', 'Data import successfully..');
        redirect('products/all_products');
          }else{
      $this->session->set_flashdata('message', 'Something went wrong..');
      redirect('uploadcsv/index');
    }
    }

}

/////////////////////////////////Import subscriber emails ////////////////////////////////

}
