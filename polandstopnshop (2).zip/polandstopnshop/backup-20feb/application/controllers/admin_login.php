<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  

class Admin_login extends CI_Controller
{
	 
	 public function __construct()
    {
        parent::__construct();
        $this->load->model('order_model');
        $this->load->model('customer_model');
        
    }

    function index(){
       
       $this->load->view('login');

    }

    function dashboard(){

        $data['latestorder']    = $this->order_model->getlatestOrder();
        $data['latestcustomer'] = $this->customer_model->getlatestcustomer();
        $this->load->view('dashboard' ,$data); 
        
    }
    
	public function login()
	{
		     $admin_email = $this->input->post('admin_email');  
         $pass = $this->input->post('password');  


        if ($this->login_model->admin_logedin( '$admin' , '$pass'))
        {
            
            $data['latestorder']    = $this->order_model->getlatestOrder();
            $data['latestcustomer'] = $this->customer_model->getlatestcustomer();
            $this->load->view('dashboard' ,$data);
        }
        else
        {
            $data['error'] = 'Your Account is Invalid'; 
            $this->load->view('login', $data);
        }
	
	}

  public function profile_view(){
        

        
        
         $this->load->view('admin/admin_profile');

       }

  
    public function update_admin_view($id){

       $id = $this->uri->segment(3);  

       $this->load->model('login_model');

       $data['admin'] = $this->login_model->get_admin_info($id);

       $this->load->view('admin/update_admin', $data);

    }

     public function update_admin(){

       $id = $this->uri->segment(3);
       $this->load->model('login_model');
       $data['r'] = $this->login_model->update_admin_info($id); 
      
      
       redirect('admin_login/profile_view');
    }

    

	public function logout()
    {
        $this->session->unset_userdata('admin_email');
        
        	redirect ('admin_login/index');
        
       
    }

    public function forgot()
    {

      $this->load->view('forgot_password');
    
       
    }

    
}
